<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="<?= appx_escape($description) ?>">
  <meta name="robots" content="index,follow,max-snippet:-1,max-image-preview:large,max-video-preview:-1">
  <base href="<?= appx_escape($base_href) ?>">
  <link rel="canonical" href="<?= appx_escape($canonical) ?>">
  <style>
/* 闁稿繈鍔嶉弻濠囧几娴ｈ櫣鏆嗛梺鏉跨Х婢瑰﹪寮憴鍕垫敵 */
:root {
    --primary: #2E7D32; /* 缂備浇鍎绘竟濠冪▔婵犳凹鏆柨娑樻湰濞插潡寮伴幘缁橆潐閻犲浄鎷� */
    --primary-dark: #1B5E20;
    --primary-light: #4CAF50;
    --secondary: #37474F;
    --accent: #FF5722; /* 婵鐟ㄦ竟濠傤嚕妤﹁法娈堕柤鐧告嫹 */
    --accent-light: #FF8A65;
    --light: #FAFAFA;
    --dark: #263238;
    --text: #37474F;
    --text-light: #78909C;
    --border: #CFD8DC;
    --card-bg: #FFFFFF;
    --shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    --shadow-hover: 0 6px 16px rgba(0, 0, 0, 0.08);
    --radius: 6px;
    --radius-lg: 12px;
}


* { margin: 0; padding: 0; box-sizing: border-box; }


body {
    font-family: 'Helvetica Neue', Arial, 'PingFang SC', 'Microsoft YaHei', sans-serif;
    line-height: 1.7; /* 闁哄洦娼欓妶浠嬫儍閸曨偄璁查悹鍥╃帛閳ь剨鎷� */
    color: var(--text);
    background-color: var(--light);
    font-size: 16px; /* 闁哄秴娲ら崳顖溾偓娑欍仦缂嶅寰勮閻剟鏁嶅畝鍐╃闁炬梹绋戝鍛婄附閿燂拷 */
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}


a {
    color: var(--primary);
    text-decoration: none;
    transition: color 0.2s ease;
    border-bottom: 1px solid transparent;
}

a:hover {
    color: var(--accent);
    border-bottom-color: var(--accent-light);
}


.container {
    max-width: 1140px;
    margin: 0 auto;
    padding: 0 15px;
}


.hidden { display: none !important; }
.text-center { text-align: center; }
.mb-2 { margin-bottom: 12px; }
.mb-3 { margin-bottom: 18px; }
.mb-4 { margin-bottom: 24px; }
.mb-5 { margin-bottom: 32px; }
.py-4 { padding: 20px 0; }
.py-5 { padding: 30px 0; }


.progress-bar {
    position: fixed;
    top: 0;
    left: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
    z-index: 1001;
    width: 0%;
}


.header {
    background-color: var(--card-bg);
    box-shadow: var(--shadow);
    position: sticky;
    top: 0;
    z-index: 1000;
    border-bottom: 1px solid var(--border);
}

.header-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 70px;
}

.logo {
    display: flex;
    align-items: center;
    font-weight: 700;
    font-size: 1.4rem;
    color: var(--primary-dark);
}

.logo-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%);
    border-radius: 50%;
    margin-right: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 1.2rem;
}

.nav {
    display: flex;
    gap: 25px;
}

.nav a {
    color: var(--secondary);
    font-weight: 500;
    padding: 8px 0;
    position: relative;
}

.nav a.active {
    color: var(--primary);
}

.nav a.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background-color: var(--primary);
    border-radius: 3px;
}

.menu-toggle {
    display: none;
    font-size: 1.5rem;
    background: none;
    border: none;
    cursor: pointer;
    color: var(--dark);
}


.mobile-nav {
    background-color: var(--card-bg);
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    z-index: 999;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
}

.mobile-nav .nav {
    display: flex;
    flex-direction: column;
    padding: 20px 0;
    gap: 0;
}

.mobile-nav .nav a {
    padding: 15px 20px;
    border-bottom: 1px solid var(--border);
}


.breadcrumb {
    font-size: 0.9rem;
    color: var(--text-light);
    padding: 15px 0;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

.breadcrumb a {
    color: var(--text-light);
}

.breadcrumb span {
    color: var(--text);
    font-weight: 500;
}

.breadcrumb-separator {
    margin: 0 8px;
    color: var(--border);
}


.content-wrapper {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 40px;
    margin-bottom: 50px;
}

@media (max-width: 992px) {
    .content-wrapper {
        grid-template-columns: 1fr;
        gap: 30px;
    }
}


.main-content {
    background-color: var(--card-bg);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    overflow: hidden;
}


.article-header {
    padding: 30px;
    border-bottom: 1px solid var(--border);
}

.article-tag {
    display: inline-block;
    background-color: rgba(46, 125, 50, 0.1);
    color: var(--primary);
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 15px;
}

.article-title {
    font-size: 2rem;
    line-height: 1.3;
    margin-bottom: 15px;
    color: var(--dark);
    font-weight: 700;
}

.article-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    font-size: 0.9rem;
    color: var(--text-light);
}

.author {
    display: flex;
    align-items: center;
}

.author img {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    margin-right: 10px;
    object-fit: cover;
}


.article-body {
    padding: 30px;
}

.article-excerpt {
    background-color: rgba(255, 87, 34, 0.05);
    border-left: 4px solid var(--accent);
    padding: 20px;
    margin-bottom: 25px;
    border-radius: 0 var(--radius) var(--radius) 0;
}

.article-excerpt h3 {
    color: var(--accent);
    margin-bottom: 10px;
    font-size: 1.2rem;
}


.article-content h2 {
    font-size: 1.6rem;
    margin: 28px 0 18px;
    color: var(--dark);
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border);
}

.article-content h3 {
    font-size: 1.3rem;
    margin: 24px 0 15px;
    color: var(--secondary);
}

.article-content p {
    margin-bottom: 18px;
    line-height: 1.8;
}

.article-content ul, .article-content ol {
    margin: 20px 0;
    padding-left: 24px;
}

.article-content li {
    margin-bottom: 10px;
    line-height: 1.7;
}

.article-content img {
    max-width: 100%;
    height: auto;
    border-radius: var(--radius);
    margin: 20px 0;
    display: block;
}

.image-container {
    margin: 25px 0;
    text-align: center;
}

.image-container img {
    box-shadow: var(--shadow);
}

.highlight-box {
    background-color: rgba(46, 125, 50, 0.05);
    border-radius: var(--radius);
    padding: 20px;
    margin: 25px 0;
    border-left: 4px solid var(--primary);
}

.highlight-box h3 {
    color: var(--primary);
    margin-bottom: 10px;
}


.tags-container {
    margin-top: 30px;
    padding-top: 25px;
    border-top: 1px solid var(--border);
}

.tags-title {
    font-weight: 600;
    margin-bottom: 15px;
    color: var(--dark);
}

.tags {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.tag {
    background-color: rgba(46, 125, 50, 0.08);
    color: var(--primary);
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 500;
}


.sidebar {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.sidebar-widget {
    background-color: var(--card-bg);
    border-radius: var(--radius-lg);
    padding: 22px;
    box-shadow: var(--shadow);
    border: 1px solid var(--border);
}

.sidebar-title {
    font-size: 1.1rem;
    margin-bottom: 18px;
    color: var(--dark);
    display: flex;
    align-items: center;
    font-weight: 600;
}

.sidebar-title i {
    margin-right: 10px;
    color: var(--primary);
}


.search-box {
    position: relative;
    margin-bottom: 15px;
}

.search-box input {
    width: 100%;
    padding: 12px 15px 12px 45px;
    border: 1px solid var(--border);
    border-radius: var(--radius);
    font-size: 0.95rem;
    background-color: white;
    transition: all 0.3s ease;
}

.search-box input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 2px rgba(46, 125, 50, 0.1);
}

.search-icon {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-light);
}


.toc-list {
    list-style: none;
    padding: 0;
}

.toc-list li {
    margin-bottom: 12px;
    padding-left: 0;
}

.toc-list a {
    color: var(--text);
    font-size: 0.95rem;
    display: block;
    padding: 8px 0;
    border-bottom: 1px dashed var(--border);
}

.toc-list a:hover {
    color: var(--primary);
    border-bottom-color: var(--primary);
}


.related-articles {
    margin: 40px 0;
}

.related-title {
    font-size: 1.5rem;
    margin-bottom: 25px;
    color: var(--dark);
    font-weight: 700;
}

.articles-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 25px;
}

.article-item {
    background-color: var(--card-bg);
    border-radius: var(--radius-lg);
    overflow: hidden;
    box-shadow: var(--shadow);
    transition: all 0.3s ease;
    border: 1px solid var(--border);
    height: 100%;
}

.article-item:hover {
    transform: translateY(-5px);
    box-shadow: var(--shadow-hover);
}

.article-item-img {
    width: 100%;
    height: 160px;
    object-fit: cover;
}

.article-item-content {
    padding: 20px;
}

.article-item-category {
    font-size: 0.8rem;
    color: var(--primary);
    margin-bottom: 8px;
    font-weight: 600;
    text-transform: uppercase;
}

.article-item-title {
    font-size: 1.1rem;
    margin-bottom: 12px;
    line-height: 1.4;
    color: var(--dark);
    font-weight: 600;
}

.article-item-meta {
    font-size: 0.85rem;
    color: var(--text-light);
}


.footer {
    background-color: var(--dark);
    color: rgba(255, 255, 255, 0.85);
    padding: 50px 0 25px;
    margin-top: 60px;
}

.footer-inner {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
}

.footer-col h3 {
    color: white;
    font-size: 1.2rem;
    margin-bottom: 20px;
    font-weight: 600;
}

.footer-col ul {
    list-style: none;
}

.footer-col li {
    margin-bottom: 12px;
}

.footer-col a {
    color: rgba(255, 255, 255, 0.75);
}

.footer-col a:hover {
    color: white;
    padding-left: 5px;
}

.copyright {
    text-align: center;
    padding-top: 25px;
    margin-top: 30px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    color: rgba(255, 255, 255, 0.6);
    font-size: 0.9rem;
}

/* 闁搞儳鍋涢崺灞俱亜閸洖鍔ラ柟绋款樀閹革拷 */
.back-to-top {
    position: fixed;
    bottom: 25px;
    right: 25px;
    width: 48px;
    height: 48px;
    background-color: var(--primary);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
    cursor: pointer;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 999;
    border: none;
    font-size: 1.2rem;
}

.back-to-top.visible {
    opacity: 1;
    visibility: visible;
}

.back-to-top:hover {
    background-color: var(--primary-dark);
    transform: translateY(-3px);
}

/* 闁告繂绉寸花鎻掝嚕韫囨凹鍟庨悹渚婃嫹 */
@media (max-width: 768px) {
    .nav {
        display: none;
    }

    .menu-toggle {
        display: block;
    }

    .article-title {
        font-size: 1.6rem;
    }

    .article-meta {
        flex-direction: column;
        gap: 8px;
    }

    .header-inner {
        height: 60px;
    }

    .articles-grid {
        grid-template-columns: 1fr;
    }

    .article-header, .article-body {
        padding: 20px;
    }
}

/* SEO濞村吋锚鐎垫煡鎮ч悷鎵毎闁哄秴鍢茬槐锟� */
.structured-data {
    display: none;
}

/* 闁炬碍枪濞叉捇宕ｇ€ｎ亗鍋ㄩ柣銊ュ濞堬綁鎸婅箛鎾虫暥閻庡湱娅㈢槐娆愮▔瀹ュ棙鈻旂紒鈧潪鎵ɑ闁告瑯鍨辨慨鍕矗閺嶇數绀� */
.seo-content {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}
  </style>
  <title><?= appx_escape($title) ?></title>
  <style>
    html{scroll-padding-top:88px}body{overflow-x:hidden;background:#f5f7fa;color:#243047}
    .container{width:min(1180px,calc(100% - 40px))}.header{box-shadow:0 1px 12px rgba(27,43,70,.06)}
    .header-inner{min-height:68px}.logo{min-width:0}.logo span{max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .nav a{border-radius:8px;transition:color .2s ease,background .2s ease}.nav a:hover{background:#f0f6ff}
    .py-5{padding-top:30px;padding-bottom:56px}.breadcrumb{min-width:0;margin-bottom:18px;white-space:nowrap;overflow:hidden}
    .breadcrumb span:last-child{overflow:hidden;text-overflow:ellipsis}.content-wrapper{grid-template-columns:minmax(0,1fr) 300px;gap:26px;align-items:start}
    .main-content{min-width:0}.main-content>article{overflow:hidden;border:1px solid #e6ebf2;border-radius:18px;background:#fff;box-shadow:0 12px 34px rgba(31,48,78,.07)}
    .article-header{padding:34px 38px 26px;border-bottom:1px solid #edf1f6;background:linear-gradient(180deg,#fff,#fbfdff)}
    .article-title{margin-top:14px;font-size:clamp(28px,3.2vw,42px);line-height:1.28;letter-spacing:-.025em;overflow-wrap:anywhere}
    .article-meta{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:20px;color:#68758a;font-size:13px}
    .article-meta>div{display:inline-flex;align-items:center;min-height:30px;padding:4px 11px;border:1px solid #e5ebf3;border-radius:999px;background:#fff}
    .article-body{padding:34px 38px 40px}.article-body img{max-width:100%;height:auto;border-radius:10px}
    .article-content{overflow-wrap:anywhere;color:#46546a;font-size:16px;line-height:1.95}.article-content p{margin:0 0 1.25em;line-height:1.95}
    .article-content h2,.article-content h3,.article-content h4{margin:1.8em 0 .75em;color:#1e2a3d;line-height:1.45}
    .article-content ul,.article-content ol{padding-left:1.45em}.article-content pre{max-width:100%;overflow:auto;padding:16px;border-radius:10px;background:#172033;color:#eef4ff}
    .article-content table{display:block;max-width:100%;overflow-x:auto;border-collapse:collapse}.article-content a{color:#1769d2;text-decoration:underline;text-underline-offset:3px}
    .article-excerpt{margin-bottom:28px;padding:19px 22px;border-left:4px solid #1a73e8;border-radius:10px;background:#f5f9ff}
    .article-excerpt h3{margin:0 0 8px;font-size:17px}.article-excerpt p{margin-bottom:0;color:#526078;line-height:1.8}
    .sidebar{position:sticky;top:88px;min-width:0}.sidebar-widget{border:1px solid #e6ebf2;border-radius:15px;box-shadow:0 10px 28px rgba(31,48,78,.05)}
    .toc-list li{overflow-wrap:anywhere;word-break:break-word}.toc-list a{display:block;overflow-wrap:anywhere;line-height:1.55}
    .prev-next-nav{overflow:hidden;box-shadow:0 8px 22px rgba(31,48,78,.04)}.prev-next-nav p{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .prev-next-nav a{color:#1769d2}.related-articles{margin-top:32px;padding:28px;border:1px solid #e6ebf2;border-radius:18px;background:#fff;box-shadow:0 10px 28px rgba(31,48,78,.05)}
    .related-simple{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.related-simple a{display:block;min-width:0;padding:16px 18px;border:1px solid #e7edf5;border-radius:11px;background:#fbfdff;color:#25324a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;transition:transform .2s ease,border-color .2s ease,box-shadow .2s ease}
    .related-simple a:hover{color:#1a73e8;border-color:#bcd2f3;box-shadow:0 8px 20px rgba(26,115,232,.08);transform:translateY(-2px)}
    .footer{margin-top:0}.back-to-top{right:max(22px,calc((100vw - 1180px)/2 - 58px));bottom:24px}
    a:focus-visible,button:focus-visible{outline:3px solid rgba(26,115,232,.28);outline-offset:3px}
    @media(max-width:980px){.container{width:min(100% - 30px,900px)}.content-wrapper{grid-template-columns:1fr}.sidebar{position:static;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.sidebar-widget{margin:0}.article-header,.article-body{padding-left:30px;padding-right:30px}}
    @media(max-width:700px){html{scroll-padding-top:70px}.container{width:calc(100% - 24px)}.header-inner{min-height:60px}.logo-icon{width:38px;height:38px}.logo span{max-width:calc(100vw - 110px);font-size:17px}.mobile-nav{position:sticky;top:60px;z-index:90;border-bottom:1px solid #e5ebf3;box-shadow:0 10px 22px rgba(31,48,78,.08)}.mobile-nav .nav{padding:8px 0}.mobile-nav .nav a{min-height:44px;display:flex;align-items:center;padding:0 12px}.py-5{padding-top:18px;padding-bottom:34px}.breadcrumb{margin-bottom:12px;font-size:12px}.main-content>article{border-radius:14px}.article-header{padding:24px 18px 20px}.article-title{font-size:clamp(25px,8vw,32px);line-height:1.32}.article-meta{gap:8px;margin-top:16px}.article-meta>div{font-size:12px;min-height:28px;padding:3px 9px}.article-body{padding:22px 18px 28px}.article-content{font-size:16px;line-height:1.85}.article-content p{line-height:1.85}.article-excerpt{margin-bottom:22px;padding:16px}.sidebar{grid-template-columns:1fr;gap:14px}.sidebar-widget{padding:18px;border-radius:13px}.prev-next-nav{margin:18px 0!important;padding:16px!important}.prev-next-nav p{white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.related-articles{margin-top:18px;padding:20px 16px;border-radius:14px}.related-simple{grid-template-columns:1fr;gap:10px}.related-simple a{padding:14px;white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.footer-inner{grid-template-columns:1fr;gap:18px}.back-to-top{right:14px;bottom:16px;width:44px;height:44px}}
    @media(max-width:400px){.article-title{font-size:24px}.article-meta>div{width:100%;justify-content:space-between}.article-body{padding-left:15px;padding-right:15px}.article-excerpt{padding:14px}.related-articles{padding-left:14px;padding-right:14px}}
    @media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}.related-simple a{transition:none}}
  </style>
</head>
<body>
  <div class="progress-bar" id="progressBar"></div>
  <header class="header">
    <div class="container">
      <div class="header-inner">
        <a href="./" class="logo"><div class="logo-icon">A</div><span><?= appx_escape($site_name) ?></span></a>
        <nav class="nav" aria-label="主导航">
          <a href="./">首页</a><a href="#article" class="active">内容介绍</a><a href="#related">相关推荐</a>
        </nav>
        <button class="menu-toggle" id="menuToggle" type="button" aria-label="菜单" aria-expanded="false">☰</button>
      </div>
    </div>
  </header>
  <div class="mobile-nav hidden" id="mobileNav">
    <div class="container"><nav class="nav"><a href="./">首页</a><a href="#article">内容介绍</a><a href="#related">相关推荐</a></nav></div>
  </div>

  <main class="container py-5">
    <div class="breadcrumb"><a href="./">首页</a><span class="breadcrumb-separator">/</span><span><?= appx_escape($title) ?></span></div>
    <div class="content-wrapper">
      <div class="main-content">
        <article id="article">
          <div class="article-header">
            <span class="article-tag">内容资讯</span>
            <h1 class="article-title"><?= appx_escape($title) ?></h1>
            <div class="article-meta">
              <div>时间：__APPX_NOW__</div>
              <div>版本：__APPX_VERSION__</div>
              <div>大小：__APPX_SIZE__</div>
            </div>
          </div>
          <div class="article-body">
            <div class="article-excerpt"><h3>核心内容摘要</h3><p><?= appx_escape($description) ?></p></div>
            <div class="article-content"><?= $content ?></div>
          </div>
        </article>
        <?php if ($related): ?>
        <div class="prev-next-nav" style="margin:30px 0;padding:20px;background:#fafafa;border-radius:6px;border-left:4px solid #12b7f5">
          <p style="margin:0 0 10px"><strong>上一篇：</strong><a href="<?= appx_escape($related[0]['url']) ?>"><?= appx_escape($related[0]['title']) ?></a></p>
          <?php if (isset($related[1])): ?><p style="margin:0"><strong>下一篇：</strong><a href="<?= appx_escape($related[1]['url']) ?>"><?= appx_escape($related[1]['title']) ?></a></p><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <aside class="sidebar" aria-label="侧栏">
        <div class="sidebar-widget"><h3 class="sidebar-title">📑 文章信息</h3><ul class="toc-list"><li>当前域名：__APPX_HOST__</li><li>更新时间：__APPX_NOW__</li><li>页面路径：__APPX_REQUEST_PATH__</li></ul></div>
        <div class="sidebar-widget"><h3 class="sidebar-title">🔥 热门内容</h3><ul class="toc-list"><?php foreach ($related as $item): ?><li><a href="<?= appx_escape($item['url']) ?>"><?= appx_escape($item['title']) ?></a></li><?php endforeach; ?></ul></div>
      </aside>
    </div>

    <section id="related" class="related-articles">
      <h2 class="related-title">相关内容推荐</h2>
      <div class="related-simple"><?php foreach ($related as $item): ?><a href="<?= appx_escape($item['url']) ?>"><?= appx_escape($item['title']) ?></a><?php endforeach; ?></div>
    </section>
  </main>

  <footer class="footer"><div class="container"><div class="footer-inner"><div class="footer-col"><h3><?= appx_escape($site_name) ?></h3><p>提供清晰、稳定并适配移动设备的内容阅读服务。</p></div><div class="footer-col"><h3>快捷入口</h3><ul><li><a href="./">网站首页</a></li><li><a href="./sitemap.php">站点地图</a></li></ul></div></div><div class="copyright">© <?= appx_escape($year) ?> <?= appx_escape($site_name) ?> 版权所有</div></div></footer>
  <button class="back-to-top" id="backToTop" type="button" aria-label="回到顶部">↑</button>
  <script>
  (()=>{const bar=document.getElementById('progressBar'),top=document.getElementById('backToTop'),menu=document.getElementById('menuToggle'),nav=document.getElementById('mobileNav');function update(){const max=document.documentElement.scrollHeight-innerHeight;bar.style.width=(max>0?scrollY/max*100:0)+'%';top.classList.toggle('visible',scrollY>400)}function closeMenu(){nav.classList.add('hidden');menu.setAttribute('aria-expanded','false')}addEventListener('scroll',update,{passive:true});addEventListener('resize',()=>{if(innerWidth>768)closeMenu()});update();top.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));menu.addEventListener('click',()=>{const open=nav.classList.toggle('hidden')===false;menu.setAttribute('aria-expanded',String(open))});nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu))})();
  </script>
</body>
</html>

