<?php
function appx_remote_url($url)
{
    $fragment = '';
    $position = strpos($url, '#');
    if ($position !== false) {
        $fragment = substr($url, $position);
        $url = substr($url, 0, $position);
    }
    $separator = strpos($url, '?') === false ? '?' : '&';
    return $url . $separator . 'appx_sync=' . time() . $fragment;
}

function appx_http_get($url, $maxBytes = 20971520)
{
    if (!appx_valid_http_url($url) || $maxBytes < 1) return null;
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 8,
            'follow_location' => 1,
            'max_redirects' => 3,
            'ignore_errors' => true,
            'header' => "User-Agent: AppXProSync/2.0\r\nAccept: application/json, text/plain;q=0.9, */*;q=0.1\r\nConnection: close\r\n",
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $stream = @fopen($url, 'rb', false, $context);
    if ($stream === false) return null;

    $metadata = stream_get_meta_data($stream);
    $headers = isset($metadata['wrapper_data']) && is_array($metadata['wrapper_data']) ? $metadata['wrapper_data'] : [];
    $status = 0;
    foreach ($headers as $header) {
        if (is_string($header) && preg_match('#^HTTP/\S+\s+(\d{3})#i', $header, $matches) === 1) {
            $status = (int) $matches[1];
        }
    }
    if ($status < 200 || $status >= 300) {
        @fclose($stream);
        return null;
    }

    $content = '';
    $length = 0;
    while (!feof($stream) && $length <= $maxBytes) {
        $chunk = @fread($stream, min(8192, $maxBytes + 1 - $length));
        if (!is_string($chunk) || $chunk === '') {
            if (feof($stream)) break;
            @fclose($stream);
            return null;
        }
        $content .= $chunk;
        $length += strlen($chunk);
    }
    @fclose($stream);
    return $content !== '' && $length <= $maxBytes ? $content : null;
}

function appx_write_if_changed($file, $content, &$changed = null)
{
    $changed = true;
    if (is_file($file) && (int) @filesize($file) === strlen($content)) {
        $existingHash = @hash_file('sha256', $file);
        if (is_string($existingHash) && hash_equals($existingHash, hash('sha256', $content))) {
            $changed = false;
            return true;
        }
    }
    return appx_atomic_write($file, $content);
}

function appx_sync_marker($name)
{
    return appx_cache_dir() . DIRECTORY_SEPARATOR . 'meta' . DIRECTORY_SEPARATOR . $name;
}

function appx_sync_due($marker, $interval)
{
    $lastRun = (int) @filemtime($marker);
    return $lastRun < 1 || time() - $lastRun >= $interval;
}

function appx_remote_config_sync($config, &$status)
{
    $configUrl = trim((string) ((isset($config['remote_config_url']) ? $config['remote_config_url'] : '')));
    if (!appx_valid_http_url($configUrl)) {
        $status['failed'][] = 'remote config URL';
        return false;
    }
    $raw = appx_http_get(appx_remote_url($configUrl), 1048576);
    if (!is_string($raw)) {
        $status['failed'][] = 'remote config download';
        return false;
    }
    $withoutBom = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
    $raw = is_string($withoutBom) ? $withoutBom : $raw;
    $json = json_decode($raw, true);
    if (!is_array($json)) {
        $status['failed'][] = 'remote config JSON';
        return false;
    }

    $runtimeFile = appx_data_dir() . DIRECTORY_SEPARATOR . '.remote-runtime.php';
    $oldRuntime = is_file($runtimeFile) ? require $runtimeFile : [];
    $oldRuntime = is_array($oldRuntime) ? $oldRuntime : [];
    $runtime = $oldRuntime;
    if (isset($json['site_name']) && is_string($json['site_name']) && trim($json['site_name']) !== '') {
        $runtime['site_name'] = trim($json['site_name']);
    }
    if (isset($json['mobile_mode']) && is_string($json['mobile_mode'])
        && in_array($json['mobile_mode'], ['normal', 'iframe'], true)) {
        $runtime['mobile_mode'] = $json['mobile_mode'];
    }
    if (isset($json['desktop_mode']) && is_string($json['desktop_mode'])
        && in_array($json['desktop_mode'], ['normal', '403'], true)) {
        $runtime['desktop_mode'] = $json['desktop_mode'];
    }

    $hasJumpUrl = isset($json['jumpUrl']) && is_string($json['jumpUrl']);
    $hasIframeUrl = isset($json['mobile_iframe_url']) && is_string($json['mobile_iframe_url']);
    if ($hasJumpUrl || $hasIframeUrl) {
        $iframeUrl = trim((string) ($hasJumpUrl ? $json['jumpUrl'] : $json['mobile_iframe_url']));
        if (!appx_valid_http_url($iframeUrl)) {
            $status['failed'][] = 'remote iframe URL';
            return false;
        }
        $runtime['remote_mobile_iframe_url'] = $iframeUrl;
        $runtime['remote_mobile_iframe_synced_at'] = time();
        /* Remove keys used by the previous build so the remote address and a
           manually entered address remain independent. */
        unset($runtime['mobile_iframe_url'], $runtime['mobile_iframe_synced_at']);
        if (!isset($json['mobile_mode'])) $runtime['mobile_mode'] = 'iframe';
    }

    $localConfigFile = appx_data_dir() . DIRECTORY_SEPARATOR . 'config.json';
    if (!appx_atomic_write($localConfigFile, $raw)) {
        $status['failed'][] = 'local config.json write';
        return false;
    }
    $payload = "<?php\nreturn " . var_export($runtime, true) . ";\n";
    if (!appx_atomic_write($runtimeFile, $payload)) {
        $status['failed'][] = 'remote runtime write';
        return false;
    }

    /* Carry the just-downloaded values into the iframe cache rebuild. This
       avoids an in-process/APCu read of the previous config.json when the new
       file has the same size and filesystem timestamp. */
    $effectiveConfig = array_replace($config, $runtime);
    $status['_iframe_url'] = function_exists('appx_iframe_url')
        ? appx_iframe_url($effectiveConfig)
        : '';
    $status['_iframe_ga_js'] = isset($json['gaJs']) && is_string($json['gaJs'])
        ? $json['gaJs']
        : '';
    $status['downloaded']++;
    $status['config_updated'] = true;
    if (((isset($oldRuntime['site_name']) ? $oldRuntime['site_name'] : null)) !== ((isset($runtime['site_name']) ? $runtime['site_name'] : null))) {
        $status['page_cache_changed'] = true;
    }
    return true;
}

function appx_remote_content_sync($config, &$status)
{
    $base = rtrim(trim((string) ((isset($config['remote_base_url']) ? $config['remote_base_url'] : ''))), '/');
    $myTitle = trim((string) ((isset($config['my_title']) ? $config['my_title'] : '')));
    $customTitle = appx_valid_http_url($myTitle);
    if ($myTitle !== '' && !$customTitle) $status['failed'][] = 'my_title URL';
    if ($base !== '' && !appx_valid_http_url($base . '/')) {
        $status['failed'][] = 'remote_base_url';
        $base = '';
    }
    if ($base === '' && !$customTitle) return false;

    $allowed = [
        'title.txt', 'description.txt', 'content.txt', 'config.txt', 'image.txt', 'links.txt',
        'content_0.txt', 'content_1.txt', 'content_2.txt', 'content_3.txt',
        'content_4.txt', 'content_5.txt', 'content_6.txt',
    ];
    $requested = [];
    foreach ((array) ((isset($config['remote_files']) ? $config['remote_files'] : [])) as $name) {
        if (is_string($name) && in_array($name, $allowed, true)) $requested[$name] = true;
    }
    if ($customTitle) $requested['title.txt'] = true;

    $attempted = 0;
    foreach (array_keys($requested) as $name) {
        $url = $name === 'title.txt' && $customTitle
            ? $myTitle
            : ($base !== '' ? $base . '/' . rawurlencode($name) : '');
        if ($url === '') continue;
        $attempted++;
        $raw = appx_http_get(appx_remote_url($url), 52428800);
        $changed = false;
        if (is_string($raw)
            && appx_write_if_changed(appx_data_dir() . DIRECTORY_SEPARATOR . $name, $raw, $changed)) {
            $status['downloaded']++;
            if ($changed) {
                $status['changed']++;
                $status['page_cache_changed'] = true;
            }
        } else {
            $status['failed'][] = $name;
        }
    }
    /* A configured source with an empty whitelist is still a completed
       schedule attempt; otherwise every page request would register it again. */
    return true;
}

function appx_remote_sync($config, $syncConfig = true, $syncContent = true)
{
    $status = [
        'time' => date('c'), 'downloaded' => 0, 'changed' => 0,
        'config_updated' => false, 'page_cache_changed' => false,
        'failed' => [], 'locked' => false,
    ];
    $metaDir = appx_cache_dir() . DIRECTORY_SEPARATOR . 'meta';
    if (!is_dir($metaDir) && !@mkdir($metaDir, 0775, true) && !is_dir($metaDir)) {
        $status['failed'][] = 'cache/meta directory';
        return $status;
    }
    $lock = @fopen($metaDir . DIRECTORY_SEPARATOR . 'remote-sync.lock', 'c');
    if ($lock === false || !@flock($lock, LOCK_EX | LOCK_NB)) {
        if (is_resource($lock)) @fclose($lock);
        $status['locked'] = true;
        return $status;
    }

    try {
        if ($syncConfig && trim((string) ((isset($config['remote_config_url']) ? $config['remote_config_url'] : ''))) !== '') {
            $interval = max(300, (int) ((isset($config['remote_config_interval']) ? $config['remote_config_interval'] : 300)));
            $success = appx_remote_config_sync($config, $status);
            $markerTime = $success ? time() : time() - $interval + 60;
            @touch(appx_sync_marker('remote-config.time'), $markerTime);
        }
        if ($syncContent) {
            $attempted = appx_remote_content_sync($config, $status);
            /* Content files always wait for the full interval after one attempt,
               even when one optional remote file is unavailable. */
            if ($attempted) @touch(appx_sync_marker('remote-content.time'));
        }
        if ($status['page_cache_changed']) appx_clear_cache();
        /* config.json is checked every five minutes. Rebuild the standalone
           iframe cache after a successful config sync so its URL and gaJs are
           refreshed together, even before the next iframe request. */
        if ($status['config_updated']
            && function_exists('appx_iframe_url')
            && function_exists('appx_refresh_iframe_cache')) {
            $latestIframeUrl = isset($status['_iframe_url']) ? (string) $status['_iframe_url'] : '';
            $latestGaJs = isset($status['_iframe_ga_js']) ? (string) $status['_iframe_ga_js'] : '';
            if ($latestIframeUrl === '') {
                $latestConfig = appx_config();
                $latestIframeUrl = appx_iframe_url($latestConfig);
            }
            if ($latestIframeUrl !== '' && !appx_refresh_iframe_cache($latestIframeUrl, true, $latestGaJs)) {
                $status['failed'][] = 'iframe cache refresh';
            }
        }
        unset($status['_iframe_url'], $status['_iframe_ga_js']);
        $statusPayload = json_encode($status, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        if (is_string($statusPayload)) appx_atomic_write($metaDir . DIRECTORY_SEPARATOR . 'remote-sync.status.json', $statusPayload . "\n");
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
    return $status;
}

function appx_schedule_remote_sync($config)
{
    static $registered = false;
    if ($registered) return;

    $configUrl = trim((string) ((isset($config['remote_config_url']) ? $config['remote_config_url'] : '')));
    $base = trim((string) ((isset($config['remote_base_url']) ? $config['remote_base_url'] : '')));
    $myTitle = trim((string) ((isset($config['my_title']) ? $config['my_title'] : '')));
    $configInterval = max(300, (int) ((isset($config['remote_config_interval']) ? $config['remote_config_interval'] : 300)));
    $contentInterval = max(300, (int) ((isset($config['remote_sync_interval']) ? $config['remote_sync_interval'] : 86400)));
    $syncConfig = appx_valid_http_url($configUrl)
        && appx_sync_due(appx_sync_marker('remote-config.time'), $configInterval);
    $hasContentSource = appx_valid_http_url(rtrim($base, '/') . '/') || appx_valid_http_url($myTitle);
    $syncContent = $hasContentSource
        && appx_sync_due(appx_sync_marker('remote-content.time'), $contentInterval);
    if (!$syncConfig && !$syncContent) return;
    $registered = true;

    register_shutdown_function(static function () use ($config, $syncConfig, $syncContent) {
        if (function_exists('fastcgi_finish_request')) {
            @fastcgi_finish_request();
        } else {
            while (ob_get_level() > 0) @ob_end_flush();
            @flush();
        }
        @ignore_user_abort(true);
        @set_time_limit(180);
        try {
            appx_remote_sync($config, $syncConfig, $syncContent);
        } catch (Exception $error) {
            error_log('AppX Pro background sync failed: ' . $error->getMessage());
        }
    });
}
