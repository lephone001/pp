<?php
$updatedDateTime = '__APPX_NOW__';
$version = '__APPX_VERSION__';
$fileSize = '__APPX_SIZE__';
$downloadCount = '__APPX_RANDOM_NUMBER__';
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="description" content="<?= appx_escape($description) ?>">
  <meta name="robots" content="index,follow">
  <base href="<?= appx_escape($base_href) ?>">
  <link rel="canonical" href="<?= appx_escape($canonical) ?>">
  <title><?= appx_escape($title) ?></title>
  <style>:root{--bg:#f5f7fb;--card:#ffffff;--text:#172033;--muted:#6d7688;--line:#e7ebf2;--blue:#2563eb;--blue-dark:#1d4ed8;--blue-soft:#eef4ff;--green:#0f9f6e;--shadow:0 14px 40px rgba(27,43,79,0.08);}*{box-sizing:border-box;}html{scroll-behavior:smooth;}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;-webkit-font-smoothing:antialiased;}a{color:inherit;text-decoration:none;}button{font:inherit;}.icon{width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}.site-page{min-height:100vh;}.shell{width:min(1120px,calc(100% - 40px));margin-inline:auto;}.topbar{position:sticky;top:0;z-index:30;border-bottom:1px solid rgba(231,235,242,0.82);background:rgba(255,255,255,0.88);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);}.topbar-inner{height:68px;display:flex;align-items:center;gap:42px;}.brand{display:inline-flex;align-items:center;gap:10px;font-size:17px;font-weight:750;letter-spacing:-0.02em;}.brand-mark{width:36px;height:36px;display:grid;place-items:center;border-radius:11px;background:var(--blue);color:#fff;box-shadow:0 8px 20px rgba(37,99,235,0.24);}.brand-mark .icon{font-size:20px;}.desktop-nav{display:flex;gap:30px;color:#525d70;font-size:14px;}.desktop-nav a:hover,.desktop-nav a:focus-visible{color:var(--blue);}.safe-link{margin-left:auto;display:inline-flex;align-items:center;gap:7px;color:var(--green);font-size:14px;font-weight:650;}.safe-link .icon{font-size:17px;}.main-content{padding:26px 0 72px;}.breadcrumb{min-height:34px;display:flex;align-items:center;gap:9px;color:#929aaa;font-size:13px;}.breadcrumb a{display:inline-flex;align-items:center;gap:6px;color:#535f72;margin-right:auto;}.breadcrumb a:hover{color:var(--blue);}.breadcrumb .icon{font-size:16px;}.hero-card,.section-card{border:1px solid var(--line);background:var(--card);box-shadow:var(--shadow);}.hero-card{margin-top:14px;overflow:hidden;border-radius:24px;}.hero-main{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:42px;align-items:center;padding:40px;}.app-overview{display:flex;gap:24px;align-items:center;min-width:0;}.app-icon{flex:0 0 auto;width:116px;height:116px;display:grid;place-items:center;border-radius:28px;color:#fff;background:linear-gradient(145deg,#4f8bff,#215bd5);box-shadow:0 18px 36px rgba(37,99,235,0.25);}.app-icon .icon{font-size:50px;stroke-width:1.8;}.app-copy{min-width:0;}.eyebrow{display:inline-flex;align-items:center;gap:6px;margin-bottom:7px;color:var(--blue);font-size:13px;font-weight:700;}.eyebrow .icon{font-size:16px;}.app-copy h1{margin:0;font-size:clamp(30px,4vw,40px);line-height:1.12;letter-spacing:-0.04em;}.app-copy > p{margin:10px 0 15px;color:var(--muted);font-size:15px;}.tag-row{display:flex;flex-wrap:wrap;gap:7px;}.tag-row span{padding:5px 9px;border-radius:7px;background:#f2f5fa;color:#526073;font-size:12px;font-weight:650;}.rating-line{display:flex;align-items:center;gap:8px;margin-top:15px;color:#7a8394;font-size:13px;}.rating-line strong{color:var(--text);}.stars{display:inline-flex;gap:2px;color:#f5a524;letter-spacing:-2px;font-size:17px;}.download-panel{display:grid;grid-template-columns:104px 1fr;gap:16px;padding:18px;border:1px solid #dfe7f5;border-radius:18px;background:#f8faff;}.qr-placeholder{display:grid;place-items:center;aspect-ratio:1;border:1px dashed #cbd6e8;border-radius:13px;background:#fff;color:#253c66;}.qr-code{width:68px;height:68px;}.download-actions{display:flex;flex-direction:column;justify-content:center;gap:9px;}.download-actions small{display:flex;align-items:center;gap:5px;color:#7c8799;font-size:11px;white-space:nowrap;}.primary-button,.secondary-button{min-height:44px;border-radius:11px;border:1px solid transparent;display:inline-flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;font-weight:700;transition:transform .18s ease,background .18s ease,box-shadow .18s ease;}.primary-button{color:#fff;background:var(--blue);box-shadow:0 10px 22px rgba(37,99,235,.22);}.primary-button:hover{background:var(--blue-dark);transform:translateY(-1px);}.secondary-button{color:#40506a;border-color:#dfe6f1;background:#fff;}.secondary-button:hover{color:var(--blue);border-color:#b8cbef;}.primary-button:focus-visible,.secondary-button:focus-visible,.recommendation-item button:focus-visible,.mobile-download-bar button:focus-visible{outline:3px solid rgba(37,99,235,.24);outline-offset:2px;}.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);border-top:1px solid var(--line);background:#fbfcfe;}.stat-grid > div{min-height:92px;display:grid;grid-template-columns:auto 1fr;align-content:center;gap:2px 10px;padding:18px 24px;border-right:1px solid var(--line);}.stat-grid > div:last-child{border-right:0;}.stat-grid .icon{grid-row:1 / 3;align-self:center;color:var(--blue);font-size:21px;}.stat-grid strong{font-size:16px;}.stat-grid span{color:var(--muted);font-size:12px;}.section-card{border-radius:20px;}.recommendation-section{margin-top:20px;padding:28px;}.section-heading{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px;}.section-heading h2,.section-title-row h2{margin:3px 0 0;font-size:21px;letter-spacing:-0.02em;}.section-kicker{color:var(--blue);font-size:11px;font-weight:800;letter-spacing:.13em;}.section-heading a{display:inline-flex;align-items:center;gap:2px;color:#667186;font-size:13px;}.section-heading a:hover{color:var(--blue);}.recommendation-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;}.recommendation-item{min-width:0;display:flex;align-items:center;gap:11px;padding:13px;border:1px solid var(--line);border-radius:15px;background:#fcfdff;}.mini-icon{flex:0 0 auto;width:46px;height:46px;display:grid;place-items:center;border-radius:13px;color:#fff;font-size:17px;font-weight:800;}.mini-icon.blue{background:#3f7bea;}.mini-icon.violet{background:#7c63d8;}.mini-icon.orange{background:#e8783e;}.mini-icon.green{background:#20a277;}.recommendation-copy{min-width:0;flex:1;}.recommendation-copy h3{margin:0;font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}.recommendation-copy p{margin:4px 0 0;color:var(--muted);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}.recommendation-item button{flex:0 0 auto;width:34px;height:34px;display:grid;place-items:center;border:0;border-radius:9px;background:var(--blue-soft);color:var(--blue);cursor:pointer;}.recommendation-item button:hover{background:var(--blue);color:#fff;}.content-grid{display:grid;grid-template-columns:minmax(0,1fr) 318px;gap:20px;align-items:start;margin-top:20px;}.content-column{display:grid;gap:20px;}.article-card{padding:30px;}.section-title-row{display:flex;align-items:center;gap:11px;margin-bottom:20px;}.section-title-row.compact{margin-bottom:14px;}.title-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;background:var(--blue-soft);color:var(--blue);}.title-icon .icon{font-size:19px;}.article-card > p{margin:0 0 14px;color:#5d687b;font-size:15px;line-height:1.9;}.feature-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:25px;}.feature-grid > div{padding:20px;border:1px solid var(--line);border-radius:15px;background:#fbfcfe;}.feature-grid span{width:38px;height:38px;display:grid;place-items:center;margin-bottom:13px;border-radius:10px;background:var(--blue-soft);color:var(--blue);}.feature-grid .icon{font-size:21px;}.feature-grid h3{margin:0;font-size:15px;}.feature-grid p{margin:7px 0 0;color:var(--muted);font-size:13px;line-height:1.65;}.update-list{list-style:none;display:grid;gap:12px;margin:0;padding:0;color:#5c687b;font-size:14px;}.update-list li{display:flex;align-items:flex-start;gap:10px;line-height:1.65;}.update-list .icon{flex:0 0 auto;margin-top:3px;color:var(--green);font-size:17px;}.safety-card{display:flex;gap:15px;padding:24px 26px;border:1px solid #cfe9df;border-radius:18px;background:#f1fbf7;color:#14785a;}.safety-card > .icon{flex:0 0 auto;font-size:27px;}.safety-card h2{margin:0 0 6px;color:#105d48;font-size:17px;}.safety-card p{margin:0;font-size:13px;line-height:1.7;}.sidebar{position:sticky;top:90px;display:grid;gap:16px;}.info-card{padding:24px;}.info-card dl{margin:0;}.info-card dl > div{display:flex;justify-content:space-between;gap:16px;padding:12px 0;border-bottom:1px solid var(--line);font-size:13px;}.info-card dt{color:var(--muted);}.info-card dd{margin:0;text-align:right;font-weight:650;}.system-note{display:flex;align-items:center;gap:9px;margin:17px 0;padding:12px;border-radius:11px;background:#f5f8fd;color:#647087;font-size:12px;}.system-note .icon{flex:0 0 auto;color:var(--blue);font-size:19px;}.sidebar-download{width:100%;}.publisher-card{display:flex;align-items:center;gap:13px;padding:20px;}.publisher-logo{width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:#edf9f4;color:var(--green);}.publisher-logo .icon{font-size:26px;}.publisher-card span,.publisher-card p{color:var(--muted);font-size:11px;}.publisher-card strong{display:block;margin:3px 0;font-size:14px;}.publisher-card p{margin:0;}.footer{border-top:1px solid var(--line);background:#fff;}.footer-inner{min-height:84px;display:flex;justify-content:space-between;align-items:center;gap:24px;color:#8992a2;font-size:12px;}.footer nav{display:flex;gap:22px;}.footer a:hover{color:var(--blue);}.mobile-download-bar{display:none;}.toast{position:fixed;z-index:70;left:50%;bottom:28px;transform:translateX(-50%);max-width:calc(100% - 32px);padding:12px 17px;border-radius:10px;background:#172033;color:#fff;box-shadow:0 12px 32px rgba(0,0,0,.18);font-size:13px;text-align:center;animation:toast-in .2s ease-out;}@keyframes toast-in{from{opacity:0;transform:translate(-50%,8px);}}@media (max-width:940px){.hero-main{grid-template-columns:1fr;}.download-panel{max-width:420px;}.recommendation-grid{grid-template-columns:repeat(2,1fr);}.content-grid{grid-template-columns:1fr;}.sidebar{position:static;grid-template-columns:1fr 1fr;}}@media (max-width:680px){body{padding-bottom:76px;}.shell{width:min(100% - 24px,1120px);}.topbar-inner{height:60px;}.desktop-nav,.safe-link{display:none;}.main-content{padding-top:14px;padding-bottom:32px;}.breadcrumb span,.breadcrumb > .icon{display:none;}.hero-card{margin-top:7px;border-radius:19px;}.hero-main{gap:28px;padding:24px 20px;}.app-overview{align-items:flex-start;gap:16px;}.app-icon{width:82px;height:82px;border-radius:21px;}.app-icon .icon{font-size:36px;}.app-copy h1{font-size:27px;}.app-copy > p{margin:7px 0 11px;font-size:13px;}.rating-line{flex-wrap:wrap;margin-top:11px;}.tag-row span{font-size:11px;}.download-panel{grid-template-columns:78px 1fr;width:100%;padding:13px;border-radius:15px;}.qr-code{width:50px;height:50px;}.download-actions small{display:none;}.stat-grid{grid-template-columns:repeat(2,1fr);}.stat-grid > div{min-height:76px;padding:14px 16px;}.stat-grid > div:nth-child(2){border-right:0;}.stat-grid > div:nth-child(-n+2){border-bottom:1px solid var(--line);}.recommendation-section,.article-card{padding:21px 18px;}.recommendation-section{border-radius:18px;}.section-heading h2,.section-title-row h2{font-size:19px;}.recommendation-grid,.feature-grid{grid-template-columns:1fr;}.content-grid{gap:14px;margin-top:14px;}.content-column{gap:14px;}.sidebar{grid-template-columns:1fr;gap:14px;}.safety-card{padding:20px;}.footer{display:none;}.mobile-download-bar{position:fixed;z-index:50;left:0;right:0;bottom:0;display:flex;justify-content:space-between;align-items:center;gap:16px;min-height:70px;padding:10px 14px calc(10px + env(safe-area-inset-bottom));border-top:1px solid var(--line);background:rgba(255,255,255,.96);box-shadow:0 -10px 30px rgba(26,38,69,.10);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}.mobile-download-bar > div{min-width:0;display:flex;flex-direction:column;}.mobile-download-bar strong{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}.mobile-download-bar span{color:var(--muted);font-size:11px;}.mobile-download-bar button{flex:0 0 auto;min-height:43px;padding:0 17px;border:0;border-radius:11px;display:inline-flex;align-items:center;gap:7px;color:#fff;background:var(--blue);font-weight:700;}.toast{bottom:84px;}}@media (max-width:420px){.app-overview{display:grid;grid-template-columns:72px 1fr;}.app-icon{width:72px;height:72px;border-radius:18px;}.eyebrow{margin-bottom:4px;}.app-copy h1{font-size:24px;}.tag-row{grid-column:1 / -1;}.download-panel{grid-template-columns:1fr;}.qr-placeholder{display:none;}.stat-grid > div{grid-template-columns:1fr;gap:3px;}.stat-grid .icon{display:none;}.mobile-download-bar button{padding-inline:14px;}}@media (prefers-reduced-motion:reduce){html{scroll-behavior:auto;}*,*::before,*::after{animation-duration:.01ms !important;transition-duration:.01ms !important;}}</style>
  <style>.mobile-download-bar .primary-button{width:200px}</style>
  <style>
    .app-copy h1{font-size:clamp(22px,2.5vw,30px);line-height:1.28;letter-spacing:-.025em;overflow-wrap:anywhere}
    .app-copy>p{font-size:14px;line-height:1.75;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
    .stat-grid strong{font-size:15px;overflow-wrap:anywhere}
    @media(max-width:680px){.app-copy h1{font-size:22px;line-height:1.32}.app-copy>p{-webkit-line-clamp:4}.stat-grid strong{font-size:14px}}
    @media(max-width:420px){.app-copy h1{font-size:20px}.stat-grid strong{font-size:13px}}
  </style>
</head>
<body>
  <!-- 内嵌 SVG 图标库，无外部文件依赖 -->
  <svg width="0" height="0" aria-hidden="true" style="position:absolute;overflow:hidden">
    <symbol id="i-cloud" viewBox="0 0 24 24"><path d="M12 13v8m-4-4 4 4 4-4"/><path d="M20.4 17.5A5 5 0 0 0 18 8.2 7 7 0 0 0 4.3 9.8 4 4 0 0 0 5 17.7"/></symbol>
    <symbol id="i-shield" viewBox="0 0 24 24"><path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3z"/><path d="m9 12 2 2 4-4"/></symbol>
    <symbol id="i-back" viewBox="0 0 24 24"><path d="m15 18-6-6 6-6"/><path d="M9 12h10"/></symbol>
    <symbol id="i-next" viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></symbol>
    <symbol id="i-drive" viewBox="0 0 24 24"><path d="M4 14.5V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9.5"/><path d="M3 14.5h18V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 6v6m-3-3 3 3 3-3"/><circle cx="17" cy="18" r=".8" fill="currentColor" stroke="none"/></symbol>
    <symbol id="i-badge" viewBox="0 0 24 24"><path d="M12 2.5 14 4l2.5-.2 1.1 2.2 2.2 1.1-.2 2.5 1.5 2-1.5 2 .2 2.5-2.2 1.1-1.1 2.2-2.5-.2-2 1.5-2-1.5-2.5.2-1.1-2.2-2.2-1.1.2-2.5-1.5-2 1.5-2-.2-2.5L6.4 6l1.1-2.2L10 4z"/><path d="m9 12 2 2 4-4"/></symbol>
    <symbol id="i-download" viewBox="0 0 24 24"><path d="M12 3v12m-4-4 4 4 4-4"/><path d="M5 21h14"/></symbol>
    <symbol id="i-copy" viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></symbol>
    <symbol id="i-lock" viewBox="0 0 24 24"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></symbol>
    <symbol id="i-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></symbol>
    <symbol id="i-refresh" viewBox="0 0 24 24"><path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/></symbol>
    <symbol id="i-file" viewBox="0 0 24 24"><path d="M5 2h10l4 4v16H5z"/><path d="M14 2v5h5M8 13h8M8 17h8"/></symbol>
    <symbol id="i-spark" viewBox="0 0 24 24"><path d="m12 3 1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/></symbol>
    <symbol id="i-gauge" viewBox="0 0 24 24"><path d="M4 18a8 8 0 1 1 16 0"/><path d="m12 15 4-4M6.5 15h.1M17.4 15h.1M12 8v.1"/></symbol>
    <symbol id="i-zap" viewBox="0 0 24 24"><path d="m13 2-9 12h8l-1 8 9-12h-8z"/></symbol>
    <symbol id="i-phone" viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M10 18h4"/></symbol>
    <symbol id="i-check" viewBox="0 0 24 24"><path d="m5 12 4 4 10-10"/></symbol>
    <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></symbol>
    <symbol id="i-monitor" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></symbol>
    <symbol id="i-circle-check" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/></symbol>
  </svg>

  <div class="site-page">
    <header class="topbar">
      <div class="shell topbar-inner">
        <a class="brand" href="<?= appx_escape($related[0]['url']) ?>" aria-label="网站首页">
          <span class="brand-mark"><svg class="icon"><use href="#i-cloud"></use></svg></span>
          <span>轻装软件站</span>
        </a>
        <nav class="desktop-nav" aria-label="主导航">
          <a href="#recommend">软件推荐</a>
          <a href="#intro">软件介绍</a>
          <a href="#update">更新日志</a>
        </nav>
        <a class="safe-link" href="#safety"><svg class="icon"><use href="#i-shield"></use></svg>安全下载说明</a>
      </div>
    </header>

    <main id="top" class="shell main-content">
      <div class="breadcrumb">
        <a href="<?= appx_escape($related[0]['url']) ?>"><svg class="icon"><use href="#i-back"></use></svg>返回首页</a>
        <span>应用工具</span>
        <svg class="icon"><use href="#i-next"></use></svg>
        <span><?= appx_escape($title) ?></span>
      </div>

      <section class="hero-card" aria-labelledby="app-title">
        <div class="hero-main">
          <div class="app-overview">
            <div class="app-icon" aria-hidden="true"><svg class="icon"><use href="#i-drive"></use></svg></div>
            <div class="app-copy">
              <div class="eyebrow"><svg class="icon"><use href="#i-badge"></use></svg>官方正版</div>
              <h1 id="app-title"><?= appx_escape($title) ?></h1>
              <p><?= appx_escape($description) ?></p>
              <div class="tag-row" aria-label="软件特点"><span>无广告</span><span>隐私安全</span><span>体积小</span></div>
              <div class="rating-line">
                <span class="stars" aria-label="评分 4.9 分">★★★★★</span>
                <strong>4.9</strong>
                <span>1,286 条评价</span>
              </div>
            </div>
          </div>

          <div class="download-panel">
            <div class="qr-placeholder" aria-label="二维码示意位置">
              <svg class="qr-code" viewBox="0 0 64 64" role="img" aria-label="二维码占位图">
                <rect width="64" height="64" rx="3" fill="#fff"/>
                <g fill="#253c66">
                  <path d="M5 5h18v18H5zm4 4v10h10V9zM41 5h18v18H41zm4 4v10h10V9zM5 41h18v18H5zm4 4v10h10V45z"/>
                  <path d="M28 5h5v5h-5zm7 0h3v8h-3zM28 14h9v4h-9zm0 7h5v6h-5zm8 1h4v5h-4zM45 28h5v5h-5zm8 0h6v4h-6zM27 31h6v5h-6zm9-1h6v9h-6zm10 7h5v5h-5zm8-2h5v9h-5zM27 41h5v5h-5zm8 1h7v4h-7zm-8 8h5v9h-5zm9-1h5v5h-5zm7-3h5v13h-5zm8 1h8v5h-8zm1 8h7v4h-7z"/>
                </g>
              </svg>
            </div>
            <div class="download-actions">
              <a class="primary-button" href="<?= appx_escape($related[0]['url']) ?>"><svg class="icon"><use href="#i-download"></use></svg>立即下载</a>
              <button class="secondary-button" id="copy-link" type="button" title="复制当前页面地址"><svg class="icon"><use href="#i-copy"></use></svg>复制页面地址</button>
              <small><svg class="icon"><use href="#i-lock"></use></svg>下载文件已通过安全检测</small>
            </div>
          </div>
        </div>

        <div class="stat-grid" aria-label="软件信息摘要">
          <div><svg class="icon"><use href="#i-calendar"></use></svg><strong>__APPX_NOW__</strong><span>发布时间</span></div>
          <div><svg class="icon"><use href="#i-refresh"></use></svg><strong>__APPX_VERSION__</strong><span>当前版本</span></div>
          <div><svg class="icon"><use href="#i-file"></use></svg><strong>__APPX_SIZE__</strong><span>文件大小</span></div>
          <div><svg class="icon"><use href="#i-cloud"></use></svg><strong>__APPX_RANDOM_NUMBER__</strong><span>累计下载</span></div>
        </div>
      </section>

      <section id="recommend" class="section-card recommendation-section">
        <div class="section-heading">
          <div><span class="section-kicker">YOU MAY ALSO LIKE</span><h2>热门软件推荐</h2></div>
          <a href="#recommend">查看全部<svg class="icon"><use href="#i-next"></use></svg></a>
        </div>
        <div class="recommendation-grid">
          <a class="recommendation-item" href="<?= appx_escape($related[0]['url']) ?>"><div class="mini-icon blue">荐</div><div class="recommendation-copy"><h3><?= appx_escape($related[0]['title']) ?></h3><p><?= appx_escape((string)((isset($related[0]['description']) ? $related[0]['description'] : $description))) ?></p></div></a>
          <a class="recommendation-item" href="<?= appx_escape($related[1]['url']) ?>"><div class="mini-icon violet">荐</div><div class="recommendation-copy"><h3><?= appx_escape($related[1]['title']) ?></h3><p><?= appx_escape((string)((isset($related[1]['description']) ? $related[1]['description'] : $description))) ?></p></div></a>
          <a class="recommendation-item" href="<?= appx_escape($related[2]['url']) ?>"><div class="mini-icon orange">荐</div><div class="recommendation-copy"><h3><?= appx_escape($related[2]['title']) ?></h3><p><?= appx_escape((string)((isset($related[2]['description']) ? $related[2]['description'] : $description))) ?></p></div></a>
          <a class="recommendation-item" href="<?= appx_escape($related[3]['url']) ?>"><div class="mini-icon green">荐</div><div class="recommendation-copy"><h3><?= appx_escape($related[3]['title']) ?></h3><p><?= appx_escape((string)((isset($related[3]['description']) ? $related[3]['description'] : $description))) ?></p></div></a>
        </div>
      </section>

      <div class="content-grid">
        <div class="content-column">
          <section id="intro" class="section-card article-card">
            <div class="section-title-row"><span class="title-icon"><svg class="icon"><use href="#i-spark"></use></svg></span><h2>软件介绍</h2></div>
            <p><?= appx_escape($description) ?></p>
            <?= $content ?>
            <p>页面采用本地分析方式，核心扫描过程无需上传个人文件。界面没有复杂入口，打开后即可完成扫描、查看和清理，适合希望保持手机整洁的普通用户。</p>
            <div class="feature-grid">
              <div><span><svg class="icon"><use href="#i-gauge"></use></svg></span><h3>快速扫描</h3><p>数秒识别可清理内容，结果分类清晰。</p></div>
              <div><span><svg class="icon"><use href="#i-shield"></use></svg></span><h3>隐私保护</h3><p>本地完成文件分析，不读取无关信息。</p></div>
              <div><span><svg class="icon"><use href="#i-zap"></use></svg></span><h3>一键清理</h3><p>确认后快速释放空间，操作简单直接。</p></div>
              <div><span><svg class="icon"><use href="#i-phone"></use></svg></span><h3>轻量省电</h3><p>安装包小巧，日常运行更节省资源。</p></div>
            </div>
          </section>

          <section id="update" class="section-card article-card">
            <div class="section-title-row"><span class="title-icon"><svg class="icon"><use href="#i-refresh"></use></svg></span><h2><?= appx_escape($version) ?> 更新日志</h2></div>
            <ul class="update-list">
              <li><svg class="icon"><use href="#i-check"></use></svg>优化大文件扫描速度，结果展示更流畅。</li>
              <li><svg class="icon"><use href="#i-check"></use></svg>新增重复图片预览，删除前可快速核对。</li>
              <li><svg class="icon"><use href="#i-check"></use></svg>修复部分机型无法读取缓存大小的问题。</li>
              <li><svg class="icon"><use href="#i-check"></use></svg>调整深色模式下的文字对比度。</li>
            </ul>
          </section>

          <section id="safety" class="safety-card">
            <svg class="icon"><use href="#i-shield"></use></svg>
            <div><h2>安全下载提示</h2><p>建议通过本页提供的官方地址下载。安装前请确认文件名称与版本信息一致，不要授予软件与核心功能无关的权限。</p></div>
          </section>
        </div>

        <aside class="sidebar" aria-label="软件详细信息">
          <section id="download-info" class="section-card info-card">
            <div class="section-title-row compact"><span class="title-icon"><svg class="icon"><use href="#i-info"></use></svg></span><h2>软件信息</h2></div>
            <dl>
              <div><dt>软件名称</dt><dd><?= appx_escape($title) ?></dd></div>
              <div><dt>当前版本</dt><dd><?= appx_escape($version) ?></dd></div>
              <div><dt>软件大小</dt><dd><?= appx_escape($fileSize) ?></dd></div>
              <div><dt>支持系统</dt><dd>Android 8.0+</dd></div>
              <div><dt>发布时间</dt><dd><?= appx_escape($updatedDateTime) ?></dd></div>
              <div><dt>软件语言</dt><dd>简体中文</dd></div>
            </dl>
            <div class="system-note"><svg class="icon"><use href="#i-monitor"></use></svg><span>支持 Android 手机与平板设备</span></div>
            <a class="primary-button sidebar-download" href="<?= appx_escape($related[0]['url']) ?>"><svg class="icon"><use href="#i-download"></use></svg>高速下载</a>
          </section>

          <section class="section-card publisher-card">
            <div class="publisher-logo"><svg class="icon"><use href="#i-circle-check"></use></svg></div>
            <div><span>开发者</span><strong>轻装工具工作室</strong><p>已通过开发者身份认证</p></div>
          </section>
        </aside>
      </div>
    </main>

    <footer class="footer">
      <div class="shell footer-inner"><span>© __APPX_YEAR__ 轻装软件站</span><nav><a href="./sitemap.php">站点地图</a><a href="#top">回到顶部</a></nav></div>
    </footer>

    <div class="mobile-download-bar">
      <div><strong><?= appx_escape($title) ?></strong><span><?= appx_escape($version) ?></span></div>
      <a class="primary-button" href="<?= appx_escape($related[0]['url']) ?>"><svg class="icon"><use href="#i-download"></use></svg>立即下载</a>
    </div>
    <div class="toast" id="toast" role="status" aria-live="polite" hidden></div>
  </div>

  <script>
    (() => {
      const toast = document.getElementById('toast');
      let toastTimer;

      function showNotice(message) {
        window.clearTimeout(toastTimer);
        toast.textContent = message;
        toast.hidden = false;
        toastTimer = window.setTimeout(() => {
          toast.hidden = true;
        }, 2400);
      }

      async function copyLink() {
        const pageUrl = window.location.href;
        try {
          await navigator.clipboard.writeText(pageUrl);
          showNotice('页面地址已复制');
        } catch (error) {
          const input = document.createElement('textarea');
          input.value = pageUrl;
          input.style.position = 'fixed';
          input.style.opacity = '0';
          document.body.appendChild(input);
          input.select();
          const copied = document.execCommand('copy');
          input.remove();
          showNotice(copied ? '页面地址已复制' : '复制失败，请手动复制浏览器地址');
        }
      }

      document.getElementById('copy-link').addEventListener('click', copyLink);
    })();
  </script>
</body>
</html>
