<?php
/* Remote synchronization worker. It must never be executable through HTTP. */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit('404 Not Found');
}

require __DIR__ . '/core.php';
require __DIR__ . '/remote_sync.php';

@ignore_user_abort(true);
@set_time_limit(300);

try {
    $result = appx_remote_sync(appx_config(), true, true);
    exit(!empty($result['locked']) ? 2 : 0);
} catch (Exception $error) {
    error_log('AppX Pro CLI sync failed: ' . $error->getMessage());
    exit(1);
}
