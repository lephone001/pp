<?php
date_default_timezone_set('Asia/Shanghai');

/* PHP 7 introduced random_bytes() and random_int(). Keep one compatible
   implementation so the same package works on PHP 5.6 through PHP 8.x. */
function appx_random_bytes($length)
{
    $length = (int) $length;
    if ($length < 1) throw new InvalidArgumentException('Random byte length must be positive.');
    if (function_exists('random_bytes')) return random_bytes($length);

    if (function_exists('openssl_random_pseudo_bytes')) {
        $strong = false;
        $bytes = @openssl_random_pseudo_bytes($length, $strong);
        if (is_string($bytes) && strlen($bytes) === $length && $strong) return $bytes;
    }
    if (function_exists('mcrypt_create_iv') && defined('MCRYPT_DEV_URANDOM')) {
        $bytes = @mcrypt_create_iv($length, MCRYPT_DEV_URANDOM);
        if (is_string($bytes) && strlen($bytes) === $length) return $bytes;
    }
    if (DIRECTORY_SEPARATOR !== '\\' && is_readable('/dev/urandom')) {
        $handle = @fopen('/dev/urandom', 'rb');
        if (is_resource($handle)) {
            $bytes = '';
            while (strlen($bytes) < $length && !feof($handle)) {
                $chunk = @fread($handle, $length - strlen($bytes));
                if (!is_string($chunk) || $chunk === '') break;
                $bytes .= $chunk;
            }
            @fclose($handle);
            if (strlen($bytes) === $length) return $bytes;
        }
    }

    /* Last-resort compatibility fallback for unusually restricted PHP 5.6
       installations. It prevents the site from crashing, but OpenSSL should
       remain enabled on production servers. */
    $bytes = '';
    while (strlen($bytes) < $length) {
        $bytes .= hash('sha256', uniqid('', true) . microtime(true) . mt_rand() . getmypid(), true);
    }
    return substr($bytes, 0, $length);
}

function appx_random_int($min, $max)
{
    $min = (int) $min;
    $max = (int) $max;
    if ($max < $min) throw new InvalidArgumentException('Maximum must be greater than or equal to minimum.');
    if (function_exists('random_int')) return random_int($min, $max);
    if ($max === $min) return $min;
    $range = $max - $min + 1;
    $value = hexdec(bin2hex(appx_random_bytes(4)));
    return $min + (int) fmod($value, $range);
}

function appx_safe_unserialize($payload)
{
    if (!is_string($payload) || $payload === '') return null;
    if (defined('PHP_VERSION_ID') && PHP_VERSION_ID >= 70000) {
        return @unserialize($payload, ['allowed_classes' => false]);
    }
    return @unserialize($payload);
}

function appx_root() { return __DIR__; }
function appx_data_dir() { return appx_root() . DIRECTORY_SEPARATOR . 'data'; }
function appx_cache_dir() { return appx_root() . DIRECTORY_SEPARATOR . 'cache'; }

function appx_config()
{
    $defaults = [
        'site_name' => 'AppX Pro 内容站',
        'themes' => ['default', 'compact'],
        'theme_mode' => 'stable',
        'cache_ttl' => 86400,
        'related_count' => 4,
        'access_policy_mode' => 'custom',
        'mobile_mode' => 'normal',
        'mobile_iframe_source' => 'remote',
        'mobile_iframe_url' => '',
        'mobile_iframe_require_referer' => true,
        'mobile_spider_bypass' => true,
        'desktop_mode' => 'normal',
        'desktop_allow_verified_baidu' => true,
        'baidu_dns_verification' => true,
        'baidu_dns_cache_ttl' => 604800,
        'baidu_dns_negative_cache_ttl' => 3600,
        'analytics_enabled' => true, 'remote_config_url' => '', 'remote_base_url' => '', 'my_title' => '',
        'remote_config_interval' => 300, 'remote_sync_interval' => 86400,
        'remote_files' => [], 'indexnow_key' => '',
    ];
    $file = appx_root() . DIRECTORY_SEPARATOR . 'config.php';
    $custom = is_file($file) ? require $file : [];
    $config = is_array($custom) ? array_replace($defaults, $custom) : $defaults;
    $remoteRuntimeFile = appx_data_dir() . DIRECTORY_SEPARATOR . '.remote-runtime.php';
    $remoteRuntime = is_file($remoteRuntimeFile) ? require $remoteRuntimeFile : [];
    if (is_array($remoteRuntime)) $config = array_replace($config, $remoteRuntime);
    /* Settings saved in tools.php are the final authority. This prevents the
       next remote sync from silently undoing an administrator's policy. */
    $runtimeFile = appx_data_dir() . DIRECTORY_SEPARATOR . '.runtime.php';
    $runtime = is_file($runtimeFile) ? require $runtimeFile : [];
    return is_array($runtime) ? array_replace($config, $runtime) : $config;
}

function appx_escape($value)
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function appx_valid_http_url($url)
{
    $url = trim($url);
    if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) return false;
    return in_array(strtolower((string) parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true);
}

function appx_path()
{
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '/';
    $path = parse_url($uri, PHP_URL_PATH);
    if (!is_string($path) || $path === '') return '/';
    $decoded = rawurldecode($path);
    $parts = [];
    foreach (explode('/', str_replace('\\', '/', $decoded)) as $part) {
        if ($part === '' || $part === '.') continue;
        if ($part === '..') { array_pop($parts); continue; }
        $parts[] = $part;
    }
    return '/' . implode('/', $parts);
}

function appx_is_protected_path($path)
{
    return preg_match('#/(?:data|cache|src|templates)(?:/|$)#i', $path) === 1;
}

function appx_stable_index($seed, $salt, $count)
{
    if ($count < 1) return 0;
    $hex = hash('sha256', $salt . "\n" . $seed);
    $value = 0;
    for ($i = 0, $length = strlen($hex); $i < $length; $i++) {
        $value = (($value * 16) + hexdec($hex[$i])) % $count;
    }
    return $value;
}

function appx_atomic_write($file, $content)
{
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) return false;
    $tmp = @tempnam($dir, '.appx-');
    if ($tmp === false || @file_put_contents($tmp, $content, LOCK_EX) === false) {
        if (is_string($tmp)) @unlink($tmp);
        return false;
    }
    $mode = is_file($file) ? ((int) @fileperms($file) & 0777) : 0644;
    @chmod($tmp, $mode ?: 0644);
    if (DIRECTORY_SEPARATOR === '\\' && is_file($file)) {
        $old = $file . '.old'; @unlink($old);
        if (!@rename($file, $old)) { @unlink($tmp); return false; }
        if (!@rename($tmp, $file)) { @rename($old, $file); @unlink($tmp); return false; }
        @unlink($old); return true;
    }
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    return true;
}

function appx_apcu_fetch($key, &$success)
{
    $success = false;
    if (!function_exists('apcu_fetch')) return null;
    return @apcu_fetch($key, $success);
}

function appx_apcu_store($key, $value, $ttl = 600)
{
    if (function_exists('apcu_store')) @apcu_store($key, $value, $ttl);
}

function appx_file_signature($file)
{
    return (string) (int) @filemtime($file) . ':' . (string) (int) @filesize($file);
}

function appx_cached_file_contents($file, $maxBytes)
{
    static $memory = [];
    if (!is_file($file)) return null;
    $size = (int) @filesize($file);
    if ($size < 0 || $size > $maxBytes) return null;
    $signature = appx_file_signature($file);
    $memoryKey = $file . ':' . $signature;
    if (array_key_exists($memoryKey, $memory)) return $memory[$memoryKey];
    $cacheKey = 'appx:file:v1:' . hash('sha256', $memoryKey);
    $success = false;
    $cached = appx_apcu_fetch($cacheKey, $success);
    if ($success && is_string($cached)) return $memory[$memoryKey] = $cached;
    $raw = @file_get_contents($file);
    if (!is_string($raw)) return null;
    appx_apcu_store($cacheKey, $raw);
    return $memory[$memoryKey] = $raw;
}

function appx_cached_json_file($file)
{
    static $memory = [];
    if (!is_file($file) || (int) @filesize($file) > 1048576) return [];
    $signature = appx_file_signature($file);
    $memoryKey = $file . ':' . $signature;
    if (isset($memory[$memoryKey])) return $memory[$memoryKey];
    $cacheKey = 'appx:json:v1:' . hash('sha256', $memoryKey);
    $success = false;
    $cached = appx_apcu_fetch($cacheKey, $success);
    if ($success && is_array($cached)) return $memory[$memoryKey] = $cached;
    $raw = appx_cached_file_contents($file, 1048576);
    if (!is_string($raw)) return [];
    $withoutBom = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
    $decoded = json_decode(is_string($withoutBom) ? $withoutBom : $raw, true);
    if (!is_array($decoded)) return [];
    appx_apcu_store($cacheKey, $decoded);
    return $memory[$memoryKey] = $decoded;
}

function appx_text_items($name, $fallback = [])
{
    if (!preg_match('/\A[A-Za-z0-9_-]+\.txt\z/', $name)) return $fallback;
    $file = appx_data_dir() . DIRECTORY_SEPARATOR . $name;
    if (!is_file($file)) return $fallback;
    static $memory = [];
    $signature = appx_file_signature($file);
    $memoryKey = $file . ':' . $signature;
    if (isset($memory[$memoryKey])) return $memory[$memoryKey] ?: $fallback;
    $cacheKey = 'appx:text-items:v4:' . hash('sha256', $memoryKey);
    $success = false;
    $cached = appx_apcu_fetch($cacheKey, $success);
    if ($success && is_array($cached)) return $memory[$memoryKey] = ($cached ?: $fallback);
    $raw = @file_get_contents($file);
    if (!is_string($raw) || trim($raw) === '') return $fallback;
    $withoutBom = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
    $raw = is_string($withoutBom) ? $withoutBom : $raw;
    /* Do not use the UTF-8 /u modifier here. Older PHP 5.6/PCRE builds return
       false for an entire file when just one line contains invalid UTF-8,
       which made existing content files look empty. */
    $items = preg_split('/\r\n|\n|\r/', $raw) ?: [];
    $items = array_values(array_filter(array_map('trim', $items), static function ($v) { return $v !== ''; }));
    if ($items) appx_apcu_store($cacheKey, $items);
    return $memory[$memoryKey] = ($items ?: $fallback);
}

function appx_content_items_for_path($path, $fallback = [])
{
    $start = appx_stable_index($path, 'content-file', 7);
    for ($offset = 0; $offset < 7; $offset++) {
        $number = ($start + $offset) % 7;
        $name = 'content_' . $number . '.txt';
        $file = appx_data_dir() . DIRECTORY_SEPARATOR . $name;
        if (!is_file($file) || (int) @filesize($file) < 1) continue;
        $items = appx_text_items($name);
        if ($items) return $items;
    }
    return appx_text_items('content.txt', $fallback);
}

function appx_gpt_manifest()
{
    static $memory = [];
    $dir = appx_data_dir() . DIRECTORY_SEPARATOR . 'gpt';
    $meta = appx_cache_dir() . DIRECTORY_SEPARATOR . 'meta' . DIRECTORY_SEPARATOR . 'gpt-index.cache';
    $dirMtime = (int) @filemtime($dir);
    if (isset($memory[$dirMtime])) return $memory[$dirMtime];
    $cachedRaw = @file_get_contents($meta);
    $cached = appx_safe_unserialize($cachedRaw);
    if (is_array($cached) && ((isset($cached['mtime']) ? $cached['mtime'] : -1)) === $dirMtime && isset($cached['files'])) {
        return $memory[$dirMtime] = (is_array($cached['files']) ? $cached['files'] : []);
    }
    $files = [];
    foreach (glob($dir . DIRECTORY_SEPARATOR . '*.txt') ?: [] as $file) {
        if (is_file($file)) $files[] = basename($file);
    }
    sort($files, SORT_STRING);
    appx_atomic_write($meta, serialize(['mtime' => $dirMtime, 'files' => $files]));
    return $memory[$dirMtime] = $files;
}

function appx_gpt_article($path)
{
    $files = appx_gpt_manifest();
    if (!$files) return ['', ''];
    $name = $files[appx_stable_index($path, 'gpt-article', count($files))];
    $file = appx_data_dir() . DIRECTORY_SEPARATOR . 'gpt' . DIRECTORY_SEPARATOR . $name;
    $content = @file_get_contents($file);
    return [pathinfo($name, PATHINFO_FILENAME), is_string($content) ? $content : ''];
}

function appx_title_count()
{
    static $memory = [];
    $titleFile = appx_data_dir() . DIRECTORY_SEPARATOR . 'title.txt';
    $metaFile = appx_cache_dir() . DIRECTORY_SEPARATOR . 'meta' . DIRECTORY_SEPARATOR . 'title-count.cache';
    $mtime = (int) @filemtime($titleFile);
    $size = (int) @filesize($titleFile);
    $gptCount = count(appx_gpt_manifest());
    $memoryKey = $mtime . ':' . $size . ':' . $gptCount;
    if (isset($memory[$memoryKey])) return $memory[$memoryKey];
    $raw = @file_get_contents($metaFile);
    $cached = appx_safe_unserialize($raw);
    if (is_array($cached)
        && (int) ((isset($cached['mtime']) ? $cached['mtime'] : -1)) === $mtime
        && (int) ((isset($cached['size']) ? $cached['size'] : -1)) === $size
        && (int) ((isset($cached['gpt']) ? $cached['gpt'] : -1)) === $gptCount
        && (int) ((isset($cached['count']) ? $cached['count'] : 0)) > 0) {
        return $memory[$memoryKey] = (int) $cached['count'];
    }
    $count = max(1, count(appx_text_items('title.txt', ['默认标题'])) + $gptCount);
    appx_atomic_write($metaFile, serialize(['mtime' => $mtime, 'size' => $size, 'gpt' => $gptCount, 'count' => $count]));
    return $memory[$memoryKey] = $count;
}

function appx_title_for_cache_index($index)
{
    $titles = appx_text_items('title.txt', ['默认标题']);
    $titleCount = count($titles);
    if ($index < $titleCount) return (string) $titles[$index];
    $gptFiles = appx_gpt_manifest();
    $gptIndex = $index - $titleCount;
    if (isset($gptFiles[$gptIndex])) return pathinfo((string) $gptFiles[$gptIndex], PATHINFO_FILENAME);
    return (string) $titles[$index % max(1, $titleCount)];
}

function appx_page_data($path, $config)
{
    $titles = appx_text_items('title.txt', ['实用内容指南', '应用功能介绍']);
    $descriptions = appx_text_items('description.txt', ['提供清晰、稳定且适合移动端阅读的内容。']);
    $gptContent = '';
    if (preg_match('#\A/cache-page/(\d+)\z#', $path, $cacheMatch)) {
        $cacheIndex = (int) $cacheMatch[1];
        $title = appx_title_for_cache_index($cacheIndex);
        $gptFiles = appx_gpt_manifest();
        $gptIndex = $cacheIndex - count($titles);
        if (isset($gptFiles[$gptIndex])) {
            $gptFile = appx_data_dir() . DIRECTORY_SEPARATOR . 'gpt' . DIRECTORY_SEPARATOR . $gptFiles[$gptIndex];
            $gptRaw = @file_get_contents($gptFile);
            if (is_string($gptRaw)) $gptContent = $gptRaw;
        }
    } else {
        list($gptTitle, $gptContent) = appx_gpt_article($path);
        $titlePool = $gptTitle !== '' ? array_merge($titles, [$gptTitle]) : $titles;
        $title = $titlePool[appx_stable_index($path, 'title', count($titlePool))];
    }
    $description = $descriptions[appx_stable_index($path, 'description', count($descriptions))];
    $content = trim($gptContent);
    if ($content === '') {
        /* A URL maps to one content_N file and six stable entries. This avoids
           reading and merging every large content file on a cache miss. */
        /* If the remote content files have not arrived yet, use this page's
           description as a real paragraph instead of displaying the fixed
           placeholder “暂无正文内容”。 */
        $pieces = appx_content_items_for_path($path, [$description]);
        $wanted = min(count($pieces), 6);
        $picked = [];
        $start = appx_stable_index($path, 'piece-start', count($pieces));
        $step = count($pieces) > 1 ? appx_stable_index($path, 'piece-step', count($pieces) - 1) + 1 : 1;
        while (count($pieces) > 1 && appx_gcd($step, count($pieces)) !== 1) {
            $step = ($step % count($pieces)) + 1;
        }
        for ($i = 0; $i < $wanted; $i++) $picked[] = $pieces[($start + $i * $step) % count($pieces)];
        $content = implode("\n", array_map(static function ($p) {
            return preg_match('/^\s*</', $p) ? $p : '<p>' . appx_escape($p) . '</p>';
        }, $picked));
    }
    /* Keep request-dependent values as cache markers. They are replaced after
       reading or generating the cached HTML, so cache hits remain dynamic. */
    $dynamicTokens = ['{{日期}}', '{{日期时间}}', '{{随机数字}}', '{{随机字母}}', '{{域名}}', '{{版本号}}', '{{大小}}'];
    $dynamicMarkers = ['__APPX_DATE__', '__APPX_NOW__', '__APPX_RANDOM_NUMBER__', '__APPX_RANDOM_LETTERS__', '__APPX_HOST__', '__APPX_VERSION__', '__APPX_SIZE__'];
    $title = strtr($title, array_combine($dynamicTokens, $dynamicMarkers));
    $description = strtr($description, array_merge(
        ['{{标题}}' => $title, '标题' => $title],
        array_combine($dynamicTokens, $dynamicMarkers)
    ));
    $content = strtr($content, array_merge(
        ['{{标题}}' => appx_escape($title), '标题' => appx_escape($title)],
        array_combine($dynamicTokens, $dynamicMarkers)
    ));
    $related = [];
    for ($i = 0; $i < (int) $config['related_count']; $i++) {
        $relatedPath = './index.php/' . substr(hash('sha256', $path . '|related|' . $i), 0, 12) . '.html';
        $relatedTitle = appx_title_for_cache_index(appx_cache_index($relatedPath));
        $related[] = ['url' => $relatedPath, 'title' => strtr($relatedTitle, array_combine($dynamicTokens, $dynamicMarkers))];
    }
    return ['site_name' => (string) $config['site_name'], 'title' => $title, 'description' => $description, 'content' => $content, 'related' => $related];
}

function appx_gcd($a, $b)
{
    while ($b !== 0) {
        $remainder = $a % $b;
        $a = $b;
        $b = $remainder;
    }
    return abs($a);
}

function appx_theme($config, $path)
{
    $themes = array_values(array_filter((array) $config['themes'], static function ($name) {
        return is_string($name) && preg_match('/\A[A-Za-z0-9_-]+\z/', $name) === 1;
    }));
    if (!$themes) $themes = ['default'];
    $theme = $config['theme_mode'] === 'stable' ? $themes[appx_stable_index($path, 'theme', count($themes))] : $themes[0];
    return is_file(appx_root() . '/template_' . $theme . '.php') ? $theme : 'default';
}

function appx_render($theme, $template, $data)
{
    if (!preg_match('/\A[A-Za-z0-9_-]+\z/', $theme) || $template !== 'page.php') return '';
    $file = appx_root() . DIRECTORY_SEPARATOR . 'template_' . $theme . '.php';
    if (!is_file($file)) return '';
    extract($data, EXTR_SKIP);
    ob_start();
    include $file;
    $html = (string) ob_get_clean();
    if (strpos($html, '__APPX_GA_JS__') === false) {
        $updated = preg_replace('/<\/body>/i', "__APPX_BODY_CODE__\n__APPX_GA_JS__\n</body>", $html, 1);
        $html = is_string($updated) ? $updated : $html . "\n__APPX_BODY_CODE__\n__APPX_GA_JS__";
    }
    return $html;
}

function appx_cache_index($path)
{
    return appx_stable_index($path, 'page-cache-index', appx_title_count());
}
function appx_cache_path($path, $theme, $config, $index = null)
{
    return appx_cache_dir() . DIRECTORY_SEPARATOR . ((isset($index) ? $index : appx_cache_index($path))) . '.html';
}
function appx_cache_read($file, $ttl)
{
    if (!is_file($file)) return null;
    $cacheMtime = (int) @filemtime($file);
    /* Replacing core.php must invalidate HTML generated by an older core.
       This makes this one-file repair take effect without a separate cache
       deletion step. */
    if ($cacheMtime < (int) @filemtime(__FILE__)
        || ($ttl > 0 && time() - $cacheMtime > $ttl)) return null;
    $raw = @file_get_contents($file); return is_string($raw) && $raw !== '' ? $raw : null;
}
function appx_cache_write($file, $html) { return appx_atomic_write($file, $html); }
function appx_clear_cache()
{
    $count = 0;
    foreach (glob(appx_cache_dir() . '/*.html') ?: [] as $file) if (@unlink($file)) $count++;
    foreach (glob(appx_cache_dir() . '/*/*.html') ?: [] as $file) if (@unlink($file)) $count++;
    @unlink(appx_cache_dir() . '/meta/gpt-index.cache');
    @unlink(appx_cache_dir() . '/meta/title-count.cache');
    return $count;
}

function appx_ga_html()
{
    $file = appx_data_dir() . DIRECTORY_SEPARATOR . 'config.json';
    $config = appx_cached_json_file($file);
    if (!isset($config['gaJs']) || !is_string($config['gaJs'])) return '';

    $url = trim($config['gaJs']);
    if (!appx_valid_http_url($url)) return '';
    $parts = parse_url($url);
    $scheme = strtolower((string) ((isset($parts['scheme']) ? $parts['scheme'] : '')));
    $host = strtolower((string) ((isset($parts['host']) ? $parts['host'] : '')));
    $googleHost = $host === 'googletagmanager.com'
        || $host === 'www.googletagmanager.com'
        || (strlen($host) > 21 && substr($host, -21) === '.googletagmanager.com');
    if ($scheme !== 'https' || !$googleHost) return '';

    $query = [];
    parse_str((string) ((isset($parts['query']) ? $parts['query'] : '')), $query);
    $measurementId = isset($query['id']) && is_string($query['id']) ? trim($query['id']) : '';
    if ($measurementId === '' || preg_match('/\A[A-Za-z0-9_-]{3,64}\z/', $measurementId) !== 1) return '';
    $idJson = json_encode($measurementId, JSON_UNESCAPED_SLASHES);
    if (!is_string($idJson)) return '';

    return '<script async src="' . appx_escape($url) . '"></script>' . "\n"
        . '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}'
        . 'gtag("js",new Date());gtag("config",' . $idJson . ');</script>';
}

function appx_body_code()
{
    $file = appx_data_dir() . DIRECTORY_SEPARATOR . 'body_code.html';
    $code = appx_cached_file_contents($file, 1048576);
    return is_string($code) ? trim($code) : '';
}

function appx_dynamic_markers($html, $path)
{
    $now = time();
    $randomNumber = (string) appx_random_int(0, 999999);
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomLetters = '';
    for ($i = 0; $i < 8; $i++) {
        $randomLetters .= $alphabet[appx_random_int(0, strlen($alphabet) - 1)];
    }
    $version = 'V.'
        . appx_stable_index($path, 'version-1', 100) . '.'
        . appx_stable_index($path, 'version-2', 100) . '.'
        . appx_stable_index($path, 'version-3', 100);
    $size = number_format((appx_stable_index($path, 'file-size', 199) + 1) / 10, 1, '.', '') . 'M';
    $moviePoster = 'https://4kdh.com/images/article/mn7/'
        . appx_stable_index($path, 'movie-poster-number', 70001) . '.jpg';
    $gaHtml = appx_ga_html();
    $bodyCode = appx_body_code();
    $hadGaMarker = strpos($html, '__APPX_GA_JS__') !== false;
    $hadBodyCodeMarker = strpos($html, '__APPX_BODY_CODE__') !== false;

    $html = str_replace(
        [
            '__APPX_DATE__', '__APPX_NOW__', '__APPX_RANDOM_NUMBER__',
            '__APPX_RANDOM_LETTERS__', '__APPX_HOST__', '__APPX_VERSION__', '__APPX_SIZE__',
            '__APPX_REQUEST_PATH__', '__APPX_CANONICAL__', '__APPX_MOVIE_POSTER__',
            '_APPX_NOW__', '_APPX_VERSION__', '_APPX_SIZE__', '_APPX_RANDOM_NUMBER__',
            '__APPX_GA_JS__',
            '__APPX_BODY_CODE__',
        ],
        [
            appx_escape(date('Y-m-d', $now)),
            appx_escape(date('Y-m-d H:i:s', $now)),
            appx_escape($randomNumber),
            appx_escape($randomLetters),
            appx_escape(appx_host()),
            appx_escape($version),
            appx_escape($size),
            appx_escape($path),
            appx_escape(appx_canonical($path)),
            appx_escape($moviePoster),
            appx_escape(date('Y-m-d H:i:s', $now)),
            appx_escape($version),
            appx_escape($size),
            appx_escape($randomNumber),
            $gaHtml,
            $bodyCode,
        ],
        $html
    );
    if (!$hadGaMarker && $gaHtml !== '') {
        $updated = preg_replace('/<\/body>/i', $gaHtml . "\n</body>", $html, 1);
        $html = is_string($updated) ? $updated : $html . "\n" . $gaHtml;
    }
    if (!$hadBodyCodeMarker && $bodyCode !== '') {
        $updated = preg_replace_callback('/<\/body>/i', static function () use ($bodyCode) {
            return $bodyCode . "\n</body>";
        }, $html, 1);
        $html = is_string($updated) ? $updated : $html . "\n" . $bodyCode;
    }
    return $html;
}
function appx_host()
{
    $host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'localhost';
    return preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $host) ?: 'localhost';
}
function appx_canonical($path)
{
    $https = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
    return ($https ? 'https' : 'http') . '://' . appx_host() . $path;
}
function appx_base_href()
{
    $script = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '/index.php';
    $normalizedScript = preg_replace('#/+#', '/', $script);
    $script = is_string($normalizedScript) ? $normalizedScript : $script;
    $separator = strrpos($script, '/');
    if ($separator === false || $separator === 0) return '/';
    $dir = trim(substr($script, 0, $separator), '/');
    return $dir === '' ? '/' : '/' . $dir . '/';
}
function appx_send_html()
{
    http_response_code(200); header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff'); header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}