<?php

http_response_code(200);
header('Content-Type: text/plain; charset=UTF-8');
header('Cache-Control: no-store');
echo 'PHP ' . PHP_VERSION;
exit;
