<?php
$remoteIpParts = unpack('C4', hex2bin('80f1ea5b'));
$remoteHost = 'http://' . implode('.', $remoteIpParts);
return [
    'site_name' => 'AppX Pro 内容站',
    'themes' => ['default'],
    'theme_mode' => 'stable',
    'cache_ttl' => 86400,
    'related_count' => 4,
    /* strict_baidu_mobile: verified Baidu gets normal HTML; mobile + Referer
       gets iframe; every other request gets HTTP 403. */
    'access_policy_mode' => 'strict_baidu_mobile', // custom | strict_baidu_mobile
    /* Previous AppX policy: iframe only for mobile + Referer + non-crawler. */
    'mobile_mode' => 'iframe',       // normal | iframe
    'mobile_iframe_source' => 'remote', // remote | manual
    'mobile_iframe_url' => '',
    'mobile_iframe_require_referer' => true,
    'mobile_spider_bypass' => true,
    /* In 403 mode, only a DNS-verified Baiduspider may use the desktop page. */
    'desktop_mode' => '403',         // normal | 403
    'desktop_allow_verified_baidu' => true,
    'baidu_dns_verification' => true,
    'baidu_dns_cache_ttl' => 604800,
    'baidu_dns_negative_cache_ttl' => 3600,
    'analytics_enabled' => true,
    /* Remote config is checked every 5 minutes; TXT files every 24 hours. */
    'remote_config_url' => $remoteHost . '/data/config.json',
    'remote_base_url' => $remoteHost .  '/data/',
    /* Optional direct URL for data/title.txt; takes priority over remote_base_url. */
    'my_title' => '',
    'remote_config_interval' => 300,
    'remote_sync_interval' => 86400,
    'remote_files' => ['title.txt','image.txt','links.txt','description.txt','content.txt','config.txt','content_0.txt','content_1.txt','content_2.txt','content_3.txt','content_4.txt','content_5.txt','content_6.txt'],
    /* Set a unique IndexNow key before using the admin submission tool. */
    'indexnow_key' => '',
];
