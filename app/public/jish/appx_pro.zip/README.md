# AppX Pro

PHP 5.6–8.x、无数据库的多模板内容程序。

## 功能

- 根目录 `template_<主题>.php` 多模板文件，按 URL 稳定选择主题。
- `data/title.txt`、`description.txt`、`content*.txt` 数据文件。
- `data/gpt/*.txt` 文章库：文件名是标题，文件内容是正文。
- `cache/<MD5前两位>/<完整MD5>.html` 完整 HTML 分片缓存。
- `/admin.php` 首次设置密码，之后编辑数据、管理 GPT 文章和清理缓存。
- `/tools.php` 提供统计、可配置访问策略、远程同步、安全上传和 IndexNow。
- 支持部署到域名根目录或任意子目录。
- 新增严格访问规则：验证成功的百度蜘蛛显示正常 HTML；移动端且有 Referer 显示 iframe（HTTP 503）；其余请求全部返回 403。
- 百度蜘蛛先检查 `Baiduspider` UA，再通过反向 DNS、百度域名后缀和正向 DNS 回验 IP；结果写入缓存，普通访客不触发 DNS。

## 部署

1. PHP 版本支持 5.6、7.x 和 8.x，无需 Composer 和数据库；PHP 5.6 建议启用 OpenSSL。
2. Apache 必须启用 `mod_rewrite` 和 `AllowOverride All`；Nginx 参考 `nginx.conf.example`。
3. PHP 进程需要对 `data/` 和 `cache/` 有读写权限。
4. 打开 `/admin.php` 创建至少 10 位的管理员密码。
5. 后台密码哈希保存在 `data/.admin-auth.php`，Web 配置已禁止访问 `data/`。

## 访问策略

- 后台“扩展工具 → 访问策略设置”保存的配置优先级最高，保存后立即生效，不会被下一次远程同步覆盖。
- `access_policy_mode=strict_baidu_mobile` 为严格策略：先放行当前验证方式确认的百度蜘蛛访问正常页；其次仅让“移动端 + 有 Referer”显示 iframe；移动端无来源、普通 PC 和其他蜘蛛全部返回 403。即使首次尚未下载远程配置，也不会绕过该限制。
- `access_policy_mode=custom` 为原来的自定义设备策略，继续使用下面的移动端和 PC 开关。
- 在自定义策略中，`mobile_mode=iframe` 可以分别控制“必须有 Referer”和“搜索蜘蛛绕过 iframe”；按旧版开关组合时，只有移动端、有 Referer、且不是搜索蜘蛛的请求显示 iframe，响应码为 503。
- iframe 地址可以选择跟随远程 `config.json` 的 `jumpUrl`，也可以使用后台手动地址；两种地址互不覆盖。
- `desktop_mode=403` 时可以控制是否放行百度蜘蛛，并可选择“UA + IP 双向 DNS 验证”或“仅 UA”；默认只放行 UA 和 IP 均验证成功的 Baiduspider。
- 只读取 `REMOTE_ADDR`。站点位于可信 CDN/反向代理后方时，应先在 Web 服务器层正确还原客户端 IP，不能直接信任访客可伪造的 `X-Forwarded-For`。
- 百度没有稳定不变的公开 IP 前缀表，因此程序不再硬编码旧 IP 段。正向/反向 DNS 验证结果默认分别缓存 7 天和 1 小时。

## 扩展工具与同步

- 远程同步只接受 `config.php` 中 `remote_files` 白名单内的 TXT。
- 配置 `my_title` 后会直接下载该 URL 并创建或更新 `data/title.txt`，优先级高于 `remote_base_url/title.txt`。
- `config.json` 每 5 分钟检查一次；TXT 每 24 小时检查一次，两个周期互不影响。
- TXT 某个文件下载失败后仍等待 24 小时，避免每次访问或每 5 分钟反复下载整批文件。
- 远程 JSON 同时兼容 `jumpUrl` 和 `mobile_iframe_url`，保存到 `data/config.json`，远程地址写入 `data/.remote-runtime.php`，不会修改 PHP 源码。
- 每次成功获取远程 iframe 地址后，实际 iframe URL 会添加或更新 `t=时间戳`。
- 远程请求采用大小受限的流式读取；同步带进程锁，同一时间只有一个请求执行下载；内容未变化时不会重写文件或清理页面缓存。
- 上传仅允许 TXT 文章以及经过图片内容检测的 JPG、PNG、WEBP、GIF。
- IndexNow 每次最多提交 100 个当前域名 URL。

## 模板变量

模板是 PHP 文件，当前传入：`site_name`、`title`、`description`、`content`、`related`、`canonical`、`base_href`、`path`、`generated_at`、`year`。

新增主题时创建根目录 `template_主题名.php`，然后将主题名加入根目录 `config.php` 的 `themes`。

## 缓存

缓存键为 `MD5(host|pathname|theme|版本)`，前两位用于目录分片。后台保存数据或文章后自动清理页面缓存和 GPT 文件索引。`cache_ttl=0` 表示永久缓存。

远程同步时间标记位于 `cache/meta/remote-config.time` 与 `cache/meta/remote-content.time`。百度 DNS 验证缓存位于 `cache/meta/baidu-dns/`。

## 安全边界

后台只允许编辑固定的数据文件和 `data/gpt/*.txt`，不提供任意路径、PHP 文件或压缩包上传。正文允许输出可信管理员预先准备的 HTML，因此不要把后台开放给不可信用户。
