<?php
require_once __DIR__ . '/core.php';

http_response_code(200);
header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

$https = isset($_SERVER['HTTPS'])
    && $_SERVER['HTTPS'] !== ''
    && strtolower((string) $_SERVER['HTTPS']) !== 'off';
$forwardedProto = isset($_SERVER['HTTP_X_FORWARDED_PROTO'])
    ? strtolower(trim(explode(',', (string) $_SERVER['HTTP_X_FORWARDED_PROTO'])[0]))
    : '';
$scheme = ($https || $forwardedProto === 'https') ? 'https' : 'http';
$host = isset($_SERVER['HTTP_HOST']) ? (string) $_SERVER['HTTP_HOST'] : 'localhost';
$host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $host) ?: 'localhost';
$origin = $scheme . '://' . $host;

/* Keep the directory in which sitemap.php is deployed, e.g. /dashboard/fr. */
$scriptName = isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '/sitemap.php';
$scriptPath = parse_url(str_replace('\\', '/', $scriptName), PHP_URL_PATH);
$basePath = is_string($scriptPath) ? str_replace('\\', '/', dirname($scriptPath)) : '';
$basePath = ($basePath === '/' || $basePath === '.' || $basePath === '\\')
    ? ''
    : '/' . trim($basePath, '/');
$entryUrl = $origin . $basePath . '/index.php';

$links = [];
$groups = ['/article/', '/app/', '/video/', '/gogogo/'];
foreach ($groups as $group) {
    $groupLinks = [];
    while (count($groupLinks) < 30) {
        try {
            $name = bin2hex(appx_random_bytes(6));
        } catch (Exception $exception) {
            $name = substr(hash('sha256', uniqid('', true) . microtime(true) . $group . count($groupLinks)), 0, 12);
        }
        $url = $entryUrl . $group . $name . '.html';
        $groupLinks[$url] = true;
    }
    $links += $groupLinks;
}

/* Add every valid URL from data/links.txt, followed by two random detail URLs
   under the same deployment directory as that sitemap.php. */
$externalLinks = [];
$externalSources = appx_text_items('links.txt', []);
foreach ($externalSources as $sourceUrl) {
    $sourceUrl = trim((string) $sourceUrl);
    if (!appx_valid_http_url($sourceUrl)) continue;

    $parts = parse_url($sourceUrl);
    if (!is_array($parts) || empty($parts['host'])) continue;
    $externalScheme = strtolower((string) (isset($parts['scheme']) ? $parts['scheme'] : 'https'));
    $externalHost = (string) $parts['host'];
    $externalPort = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
    $externalPath = isset($parts['path']) ? str_replace('\\', '/', (string) $parts['path']) : '/sitemap.php';
    $externalDirectory = str_replace('\\', '/', dirname($externalPath));
    $externalDirectory = ($externalDirectory === '/' || $externalDirectory === '.')
        ? ''
        : '/' . trim($externalDirectory, '/');
    $externalEntry = $externalScheme . '://' . $externalHost . $externalPort
        . $externalDirectory . '/index.php/';

    $externalLinks[$sourceUrl] = true;
    for ($i = 0; $i < 2; $i++) {
        try {
            $randomName = bin2hex(appx_random_bytes(6));
        } catch (Exception $exception) {
            $randomName = substr(hash('sha256', uniqid('', true) . microtime(true) . $sourceUrl . $i), 0, 12);
        }
        $externalLinks[$externalEntry . $randomName . '.html'] = true;
    }
}

function sitemap_escape($value)
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex,follow">
  <title>网站链接</title>
  <style>
    *{box-sizing:border-box}body{margin:0;background:#f5f7fb;color:#172033;font:15px/1.7 system-ui,-apple-system,"Microsoft YaHei",sans-serif}
    main{width:min(1000px,calc(100% - 28px));margin:28px auto;padding:24px;border:1px solid #e3e9f2;border-radius:16px;background:#fff;box-shadow:0 12px 34px rgba(25,42,75,.07)}
    h1{margin:0 0 18px;font-size:24px}h2{margin:26px 0 12px;padding-top:22px;border-top:1px solid #e3e9f2;font-size:20px}.links{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 18px}
    a{min-width:0;padding:8px 10px;border-radius:7px;color:#2563eb;text-decoration:none;overflow-wrap:anywhere}a:hover{background:#eef4ff}
    @media(max-width:680px){main{margin:14px auto;padding:16px}.links{grid-template-columns:1fr}h1{font-size:20px}}
  </style>
</head>
<body>
<main>
  <h1>网站链接</h1>
  <div class="links">
    <?php foreach (array_keys($links) as $url): ?>
      <a href="<?= sitemap_escape($url) ?>"><?= sitemap_escape($url) ?></a>
    <?php endforeach; ?>
  </div>
  <?php if ($externalLinks): ?>
    <h2>更多网站链接</h2>
    <div class="links external-links">
      <?php foreach (array_keys($externalLinks) as $url): ?>
        <a href="<?= sitemap_escape($url) ?>"><?= sitemap_escape($url) ?></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</main>
</body>
</html>
