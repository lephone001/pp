<?php
function appx_user_agent()
{
    return isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 1000) : '';
}

function appx_request_ip()
{
    $ip = isset($_SERVER['REMOTE_ADDR']) ? trim((string) $_SERVER['REMOTE_ADDR']) : '';
    return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '';
}

function appx_is_mobile_user_agent($ua)
{
    return preg_match('/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|HarmonyOS/i', $ua) === 1;
}

function appx_has_mobile_client_hint()
{
    /* Chromium sends this header for mobile device profiles, including when
       DevTools device emulation keeps a reduced or desktop-looking UA. */
    $hint = isset($_SERVER['HTTP_SEC_CH_UA_MOBILE'])
        ? strtolower(trim((string) $_SERVER['HTTP_SEC_CH_UA_MOBILE']))
        : '';
    if ($hint === '?1' || $hint === '1' || $hint === 'true') return true;

    /* Compatibility with older mobile browsers and a few mobile proxies. */
    return !empty($_SERVER['HTTP_X_WAP_PROFILE'])
        || !empty($_SERVER['HTTP_PROFILE'])
        || !empty($_SERVER['HTTP_X_OPERAMINI_PHONE_UA']);
}

function appx_is_mobile_request()
{
    return appx_is_mobile_user_agent(appx_user_agent()) || appx_has_mobile_client_hint();
}

function appx_is_spider_user_agent($ua)
{
    return preg_match('/Baiduspider|Googlebot|bingbot|Sogou|360Spider|YisouSpider|Bytespider|Slurp|PetalBot|crawler|spider|bot\b/i', $ua) === 1;
}

function appx_is_baidu_user_agent($ua)
{
    return stripos($ua, 'Baiduspider') !== false;
}

function appx_hostname_has_suffix($hostname, $suffix)
{
    $hostname = strtolower(rtrim($hostname, '.'));
    $suffix = strtolower(ltrim($suffix, '.'));
    return $hostname === $suffix
        || (strlen($hostname) > strlen($suffix)
            && substr($hostname, -strlen($suffix) - 1) === '.' . $suffix);
}

function appx_same_ip($left, $right)
{
    $leftBinary = @inet_pton($left);
    $rightBinary = @inet_pton($right);
    return is_string($leftBinary) && is_string($rightBinary) && hash_equals($leftBinary, $rightBinary);
}

function appx_hostname_resolves_to_ip($hostname, $ip)
{
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
        foreach (@gethostbynamel($hostname) ?: [] as $resolvedIp) {
            if (appx_same_ip($resolvedIp, $ip)) return true;
        }
        return false;
    }
    if (!function_exists('dns_get_record') || !defined('DNS_AAAA')) return false;
    foreach (@dns_get_record($hostname, DNS_AAAA) ?: [] as $record) {
        if (isset($record['ipv6']) && is_string($record['ipv6']) && appx_same_ip($record['ipv6'], $ip)) return true;
    }
    return false;
}

function appx_baidu_dns_cache_file($ip)
{
    return appx_cache_dir() . DIRECTORY_SEPARATOR . 'meta' . DIRECTORY_SEPARATOR
        . 'baidu-dns' . DIRECTORY_SEPARATOR . hash('sha256', $ip) . '.cache';
}

function appx_baidu_dns_cache_read($ip, $positiveTtl, $negativeTtl)
{
    $key = 'appx:baidu-dns:v1:' . hash('sha256', $ip);
    if (function_exists('apcu_fetch')) {
        $success = false;
        $cached = apcu_fetch($key, $success);
        if ($success && is_bool($cached)) return $cached;
    }
    $file = appx_baidu_dns_cache_file($ip);
    $raw = @file_get_contents($file);
    if (!is_string($raw) || ($raw !== '1' && $raw !== '0')) return null;
    $verified = $raw === '1';
    $ttl = $verified ? $positiveTtl : $negativeTtl;
    if (time() - (int) @filemtime($file) >= $ttl) return null;
    if (function_exists('apcu_store')) @apcu_store($key, $verified, $ttl);
    return $verified;
}

function appx_baidu_dns_cache_write($ip, $verified, $ttl)
{
    $key = 'appx:baidu-dns:v1:' . hash('sha256', $ip);
    if (function_exists('apcu_store')) @apcu_store($key, $verified, $ttl);
    appx_atomic_write(appx_baidu_dns_cache_file($ip), $verified ? '1' : '0');
}

function appx_is_verified_baidu_ip($ip, $config)
{
    if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    }
    $positiveTtl = max(300, min(2592000, (int) ((isset($config['baidu_dns_cache_ttl']) ? $config['baidu_dns_cache_ttl'] : 604800))));
    $negativeTtl = max(60, min(86400, (int) ((isset($config['baidu_dns_negative_cache_ttl']) ? $config['baidu_dns_negative_cache_ttl'] : 3600))));
    $cached = appx_baidu_dns_cache_read($ip, $positiveTtl, $negativeTtl);
    if ($cached !== null) return $cached;

    $hostname = @gethostbyaddr($ip);
    $verified = is_string($hostname)
        && $hostname !== $ip
        && (appx_hostname_has_suffix($hostname, 'baidu.com') || appx_hostname_has_suffix($hostname, 'baidu.jp'))
        && appx_hostname_resolves_to_ip($hostname, $ip);
    appx_baidu_dns_cache_write($ip, $verified, $verified ? $positiveTtl : $negativeTtl);
    return $verified;
}

function appx_request_context($config)
{
    static $contexts = [];
    $ua = appx_user_agent();
    $ip = appx_request_ip();
    $referer = isset($_SERVER['HTTP_REFERER']) ? trim((string) $_SERVER['HTTP_REFERER']) : '';
    $verifyDns = !array_key_exists('baidu_dns_verification', $config) || !empty($config['baidu_dns_verification']);
    $cacheKey = hash('sha256', $ua . "\n" . $ip . "\n" . $referer . "\n" . ($verifyDns ? '1' : '0'));
    if (isset($contexts[$cacheKey])) return $contexts[$cacheKey];

    $baiduUa = appx_is_baidu_user_agent($ua);
    /* DNS is deliberately attempted only for a Baiduspider UA. Normal traffic
       never waits for a reverse lookup. REMOTE_ADDR must already be the real
       client IP when a trusted CDN or reverse proxy is in front of PHP. */
    $baiduIp = $baiduUa && $verifyDns ? appx_is_verified_baidu_ip($ip, $config) : false;
    $verifiedBaidu = $baiduUa && (!$verifyDns || $baiduIp);
    return $contexts[$cacheKey] = [
        'user_agent' => $ua,
        'ip' => $ip,
        'referer' => $referer,
        'mobile' => appx_is_mobile_user_agent($ua) || appx_has_mobile_client_hint(),
        'spider_ua' => appx_is_spider_user_agent($ua),
        'baidu_ua' => $baiduUa,
        'baidu_ip' => $baiduIp,
        'baidu_verified' => $verifiedBaidu,
        'has_referer' => $referer !== '',
    ];
}

function appx_iframe_url($config)
{
    $source = ((isset($config['mobile_iframe_source']) ? $config['mobile_iframe_source'] : 'remote')) === 'manual' ? 'manual' : 'remote';
    if ($source === 'manual') {
        $url = trim((string) ((isset($config['mobile_iframe_url']) ? $config['mobile_iframe_url'] : '')));
        $timestamp = (int) ((isset($config['mobile_iframe_manual_updated_at']) ? $config['mobile_iframe_manual_updated_at'] : 0));
    } else {
        $url = trim((string) ((isset($config['remote_mobile_iframe_url']) ? $config['remote_mobile_iframe_url'] : '')));
        $timestamp = (int) ((isset($config['remote_mobile_iframe_synced_at']) ? $config['remote_mobile_iframe_synced_at'] : 0));
        /* Backward compatibility with an existing .remote-runtime.php created
           by the previous build. It is migrated on the next successful sync. */
        if (!appx_valid_http_url($url)) {
            $url = trim((string) ((isset($config['mobile_iframe_url']) ? $config['mobile_iframe_url'] : '')));
            $timestamp = (int) ((isset($config['mobile_iframe_synced_at']) ? $config['mobile_iframe_synced_at'] : 0));
        }
    }
    if (!appx_valid_http_url($url)) return '';
    if ($timestamp < 1) return $url;

    $fragment = '';
    $hashPosition = strpos($url, '#');
    if ($hashPosition !== false) {
        $fragment = substr($url, $hashPosition);
        $url = substr($url, 0, $hashPosition);
    }
    if (preg_match('/([?&])t=[^&#]*/i', $url) === 1) {
        $updatedUrl = preg_replace('/([?&])t=[^&#]*/i', '$1t=' . $timestamp, $url, 1);
        $url = is_string($updatedUrl) ? $updatedUrl : $url;
    } else {
        $last = substr($url, -1);
        $separator = strpos($url, '?') === false ? '?' : (($last === '?' || $last === '&') ? '' : '&');
        $url .= $separator . 't=' . $timestamp;
    }
    return $url . $fragment;
}

function appx_access_policy_mode($config)
{
    return ((isset($config['access_policy_mode']) ? $config['access_policy_mode'] : 'custom')) === 'strict_baidu_mobile'
        ? 'strict_baidu_mobile'
        : 'custom';
}

function appx_access_decision($config, $request)
{
    /* Highest-priority rule: once the request is identified as Baiduspider by
       the configured verification method, it always receives the normal
       article page. Device type, Referer, iframe settings, desktop 403 and
       custom/strict policy modes must never override this decision. */
    if (!empty($request['baidu_verified'])) return 'normal';

    if (appx_access_policy_mode($config) === 'strict_baidu_mobile') {
        /* Strict policy is fixed: verified Baidu gets normal HTML; a regular
           mobile visitor with Referer gets iframe; every other request is
           forbidden. Device switches are intentionally ignored here. */
        $hasIframeCache = function_exists('appx_iframe_cache_available')
            && appx_iframe_cache_available();
        if (!empty($request['mobile'])
            && !empty($request['has_referer'])
            && empty($request['spider_ua'])
            && ($hasIframeCache || appx_iframe_url($config) !== '')) {
            return 'iframe';
        }
        return 'forbidden';
    }

    $allowBaidu = !array_key_exists('desktop_allow_verified_baidu', $config)
        || !empty($config['desktop_allow_verified_baidu']);
    if (empty($request['mobile'])
        && ((isset($config['desktop_mode']) ? $config['desktop_mode'] : 'normal')) === '403'
        && !($allowBaidu && !empty($request['baidu_verified']))) {
        return 'forbidden';
    }

    /* Custom policy must honor the device settings saved in tools.php. */
    $requireReferer = !array_key_exists('mobile_iframe_require_referer', $config)
        || !empty($config['mobile_iframe_require_referer']);
    $spiderBypass = !array_key_exists('mobile_spider_bypass', $config)
        || !empty($config['mobile_spider_bypass']);
    if (!empty($request['mobile'])
        && (!$requireReferer || !empty($request['has_referer']))
        && (!$spiderBypass || empty($request['spider_ua']))
        && ((isset($config['mobile_mode']) ? $config['mobile_mode'] : 'normal')) === 'iframe') {
        return 'iframe';
    }
    return 'normal';
}

function appx_forbidden()
{
    http_response_code(403);
    header('Content-Type: text/plain; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    exit('403 Forbidden');
}

function appx_iframe_cache_file()
{
    return appx_cache_dir() . DIRECTORY_SEPARATOR . 'iframe.html';
}

function appx_iframe_cache_available()
{
    $file = appx_iframe_cache_file();
    clearstatcache(true, $file);
    return is_file($file) && (int) @filesize($file) > 0;
}

function appx_iframe_cache_is_fresh($file)
{
    if (!is_file($file) || (int) @filesize($file) < 1) return false;
    $mtime = (int) @filemtime($file);
    if ($mtime < 1 || $mtime < (int) @filemtime(__FILE__)) return false;
    return time() - $mtime < 300;
}

function appx_iframe_ga_html($gaJs)
{
    $url = is_string($gaJs) ? trim($gaJs) : '';
    if (!appx_valid_http_url($url)) return '';
    $parts = parse_url($url);
    $scheme = strtolower((string) (isset($parts['scheme']) ? $parts['scheme'] : ''));
    $host = strtolower((string) (isset($parts['host']) ? $parts['host'] : ''));
    $googleHost = $host === 'googletagmanager.com'
        || $host === 'www.googletagmanager.com'
        || (strlen($host) > 21 && substr($host, -21) === '.googletagmanager.com');
    if ($scheme !== 'https' || !$googleHost) return '';

    $query = [];
    parse_str((string) (isset($parts['query']) ? $parts['query'] : ''), $query);
    $measurementId = isset($query['id']) && is_string($query['id']) ? trim($query['id']) : '';
    if ($measurementId === '' || preg_match('/\A[A-Za-z0-9_-]{3,64}\z/', $measurementId) !== 1) return '';
    $idJson = json_encode($measurementId, JSON_UNESCAPED_SLASHES);
    if (!is_string($idJson)) return '';

    return '<script async src="' . appx_escape($url) . '"></script>' . "\n"
        . '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}'
        . 'gtag("js",new Date());gtag("config",' . $idJson . ');</script>';
}

function appx_build_iframe_html($url, $gaJs = null)
{
    $safe = appx_escape($url);
    $gaHtml = $gaJs === null
        ? (function_exists('appx_ga_html') ? appx_ga_html() : '')
        : appx_iframe_ga_html($gaJs);
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
        . '<meta name="robots" content="noindex,nofollow"><title>页面加载中</title>'
        . '<style>*{box-sizing:border-box}html,body,iframe{width:100%;height:100%;margin:0;border:0}'
        . 'body{overflow:hidden;background:#fff}iframe{display:block}</style></head><body>'
        . '<iframe src="' . $safe . '" title="页面内容" '
        . 'referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>'
        . ($gaHtml !== '' ? "\n" . $gaHtml . "\n" : '')
        . '</body></html>';
}

function appx_refresh_iframe_cache($url, $force = false, $gaJs = null)
{
    if (!appx_valid_http_url($url)) return false;
    $cacheFile = appx_iframe_cache_file();
    clearstatcache(true, $cacheFile);
    if (!$force && appx_iframe_cache_is_fresh($cacheFile)) return true;

    $cacheDir = appx_cache_dir();
    if (!is_dir($cacheDir) && !@mkdir($cacheDir, 0775, true) && !is_dir($cacheDir)) return false;
    $lock = @fopen($cacheDir . DIRECTORY_SEPARATOR . '.iframe-cache.lock', 'c');
    if ($lock === false) return appx_atomic_write($cacheFile, appx_build_iframe_html($url, $gaJs));

    $written = false;
    if (@flock($lock, LOCK_EX)) {
        clearstatcache(true, $cacheFile);
        if (!$force && appx_iframe_cache_is_fresh($cacheFile)) {
            $written = true;
        } else {
            $written = appx_atomic_write($cacheFile, appx_build_iframe_html($url, $gaJs));
            clearstatcache(true, $cacheFile);
        }
        @flock($lock, LOCK_UN);
    }
    @fclose($lock);
    return $written;
}

function appx_send_iframe($url)
{
    http_response_code(503);
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Content-Type-Options: nosniff');
    header('X-AppX-Response: iframe-cache');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    $cacheFile = appx_iframe_cache_file();

    /* The five-minute shutdown sync owns cache refreshes. Matching visitors
       get the existing static file immediately, without parsing config again. */
    if (appx_iframe_cache_available() && @readfile($cacheFile) !== false) exit;

    /* First-run fallback: build the file once when no cache exists yet. */
    if (appx_valid_http_url($url)
        && appx_refresh_iframe_cache($url, true)
        && @readfile($cacheFile) !== false) {
        exit;
    }

    /* Keep the iframe available if the cache directory is temporarily not
       writable. Normal requests use cache/iframe.html directly. */
    if (appx_valid_http_url($url)) echo appx_build_iframe_html($url);
    exit;
}

function appx_apply_access_policy($config)
{
    $request = appx_request_context($config);
    $decision = appx_access_decision($config, $request);
    if ($decision === 'forbidden') appx_forbidden();
    if ($decision === 'iframe') {
        $url = appx_iframe_url($config);
        if ($url === '' && !appx_iframe_cache_available()) {
            if (appx_access_policy_mode($config) === 'strict_baidu_mobile') appx_forbidden();
            return;
        }
        appx_send_iframe($url);
    }
}