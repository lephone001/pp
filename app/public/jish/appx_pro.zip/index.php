<?php
require __DIR__ . '/core.php';
require __DIR__ . '/access.php';
require __DIR__ . '/analytics.php';
require __DIR__ . '/remote_sync.php';

$path = appx_path();
if (appx_is_protected_path($path)) {
    http_response_code(404);
    exit('404 Not Found');
}

$config = appx_config();
$indexNowKey = (string) ((isset($config['indexnow_key']) ? $config['indexnow_key'] : ''));
if ($indexNowKey !== '' && preg_match('/\A[A-Za-z0-9_-]{8,128}\z/', $indexNowKey)
    && basename($path) === $indexNowKey . '.txt') {
    http_response_code(200); header('Content-Type: text/plain; charset=UTF-8');
    echo $indexNowKey; exit;
}
appx_schedule_remote_sync($config);

$strictAccessPolicy = appx_access_policy_mode($config) === 'strict_baidu_mobile';
if ($strictAccessPolicy) {
    appx_record_visit($path, $config);
    appx_apply_access_policy($config);
}

/* Preserve the previous first-run behavior: return immediately while the
   shutdown task downloads the first remote config. The strict policy must be
   enforced before this shortcut, otherwise an ordinary request could receive
   HTTP 200 during first-run. */
$localRemoteConfig = appx_data_dir() . DIRECTORY_SEPARATOR . 'config.json';
if (!$strictAccessPolicy
    && appx_valid_http_url(trim((string) ((isset($config['remote_config_url']) ? $config['remote_config_url'] : ''))))
    && !is_file($localRemoteConfig)
    && trim((string) ((isset($config['mobile_iframe_url']) ? $config['mobile_iframe_url'] : ''))) === '') {
    http_response_code(200);
    header('Content-Type: text/plain; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    exit('OK');
}

if (!$strictAccessPolicy) {
    appx_record_visit($path, $config);
    appx_apply_access_policy($config);
}
$theme = appx_theme($config, $path);
$pageIndex = appx_cache_index($path);
$cacheFile = appx_cache_path($path, $theme, $config, $pageIndex);
$cached = appx_cache_read($cacheFile, (int) $config['cache_ttl']);
if ($cached !== null) {
    appx_send_html();
    echo appx_dynamic_markers($cached, $path);
    exit;
}

$cacheSeed = '/cache-page/' . $pageIndex;
$data = appx_page_data($cacheSeed, $config);
$data['theme'] = $theme;
$data['canonical'] = '__APPX_CANONICAL__';
$data['base_href'] = appx_base_href();
$data['path'] = $path;
$data['generated_at'] = date('Y-m-d H:i:s');
$data['year'] = date('Y');

$html = appx_render($theme, 'page.php', $data);
if ($html === '') {
    http_response_code(500);
    exit('Template unavailable');
}
appx_cache_write($cacheFile, $html);
appx_send_html();
echo appx_dynamic_markers($html, $path);
