<?php
/*
 * AppX Pro 影视详情模板
 *
 * 与现有模板相同，基础运行只依赖：
 * $site_name、$title、$description、$content、$related、$canonical、$base_href、$year。
 *
 * 如果核心以后提供 $movie_data，可自动增强影视字段：
 * [
 *   'poster' => 'https://example.com/poster.jpg',
 *   'area' => '中国大陆',
 *   'class' => '剧情 / 悬疑',
 *   'year' => '2026',
 *   'director' => '导演姓名',
 *   'actors' => ['演员甲', '演员乙'],
 *   'language' => '汉语普通话',
 *   'status' => '全 24 集',
 *   'quality' => '高清',
 *   'content_type' => 1, // 1电视剧、2电影、3综艺、4教育、5动漫、6纪录片
 *   'episodes' => [
 *      ['title' => '第1集', 'url' => '/play/example-1.html'],
 *   ],
 * ]
 */

$movieData = [];
if (isset($movie_data) && is_array($movie_data)) {
    $movieData = $movie_data;
} elseif (isset($movie) && is_array($movie)) {
    $movieData = $movie;
} elseif (isset($video) && is_array($video)) {
    $movieData = $video;
}

$movieTitle = trim((string) ((isset($movieData['title']) ? $movieData['title'] : $title)));
if ($movieTitle === '') $movieTitle = (string) $title;
$movieDescription = trim((string) ((isset($movieData['description']) ? $movieData['description'] : $description)));
if ($movieDescription === '') $movieDescription = (string) $description;

$movieArea = trim((string) ((isset($movieData['area']) ? $movieData['area'] : '')));
$movieClass = trim((string) ((isset($movieData['class']) ? $movieData['class'] : (isset($movieData['genre']) ? $movieData['genre'] : ''))));
$movieYear = trim((string) ((isset($movieData['year']) ? $movieData['year'] : '')));
$movieDirector = trim((string) ((isset($movieData['director']) ? $movieData['director'] : '')));
$movieLanguage = trim((string) ((isset($movieData['language']) ? $movieData['language'] : '')));
$movieStatus = trim((string) ((isset($movieData['status']) ? $movieData['status'] : '')));
$movieQuality = trim((string) ((isset($movieData['quality']) ? $movieData['quality'] : '')));
$movieContentType = trim((string) ((isset($movieData['content_type']) ? $movieData['content_type'] : '')));

$actorSource = (isset($movieData['actors']) ? $movieData['actors'] : (isset($movieData['actor']) ? $movieData['actor'] : []));
if (is_string($actorSource)) {
    $actorSource = preg_split('/[,，、\/]+/u', $actorSource) ?: [];
}
$movieActors = [];
if (is_array($actorSource)) {
    foreach ($actorSource as $actor) {
        $actor = trim((string) $actor);
        if ($actor !== '') $movieActors[] = $actor;
    }
}
$movieActors = array_values(array_unique($movieActors));
$movieActorsText = implode('、', $movieActors);

$toAbsoluteUrl = static function ($url) use ($canonical, $base_href) {
    $url = trim($url);
    if ($url === '') return '';
    if (preg_match('#^https?://#i', $url)) return $url;

    $canonicalParts = parse_url((string) $canonical);
    $scheme = isset($canonicalParts['scheme']) ? (string) $canonicalParts['scheme'] : 'https';
    $host = isset($canonicalParts['host']) ? (string) $canonicalParts['host'] : '';
    $port = isset($canonicalParts['port']) ? ':' . (int) $canonicalParts['port'] : '';
    if (strpos($url, '//') === 0) return $scheme . ':' . $url;
    if ($host === '') return $url;

    $origin = $scheme . '://' . $host . $port;
    if (strpos($url, '/') === 0) return $origin . $url;
    return $origin . rtrim((string) $base_href, '/') . '/' . ltrim($url, '/');
};

$moviePoster = '__APPX_MOVIE_POSTER__';

$episodes = [];
$moviePageUrl = static function ($salt) use ($movieTitle) {
    return './index.php/' . substr(hash('sha256', $movieTitle . '|movie-link|' . $salt), 0, 12) . '.html';
};
$episodeSeed = isset($path) && is_string($path) && $path !== '' ? $path : $movieTitle;
$episodeCount = 6 + appx_stable_index($episodeSeed, 'movie-episode-count', 95);
$defaultEpisodeNumbers = range(1, $episodeCount);
foreach ($defaultEpisodeNumbers as $episodeNumber) {
    $episodeUrl = $moviePageUrl('episode-' . $episodeNumber);
    $episodes[] = [
        'title' => '第' . $episodeNumber . '集',
        'url' => $episodeUrl,
        'absolute_url' => $toAbsoluteUrl($episodeUrl),
    ];
}

$schemaType = 'VideoObject';
if ($movieContentType === '1') $schemaType = 'TVSeries';
if ($movieContentType === '2') $schemaType = 'Movie';
if ($movieContentType === '5') $schemaType = 'TVSeries';

$movieSchema = [
    '@context' => 'https://schema.org',
    '@type' => $schemaType,
    'name' => $movieTitle,
    'description' => $movieDescription,
    'url' => (string) $canonical,
    'inLanguage' => $movieLanguage !== '' ? $movieLanguage : 'zh-CN',
];
if ($moviePoster !== '') $movieSchema['image'] = $moviePoster;
if ($movieYear !== '' && preg_match('/\A\d{4}\z/', $movieYear)) $movieSchema['dateCreated'] = $movieYear;
if ($movieDirector !== '') $movieSchema['director'] = ['@type' => 'Person', 'name' => $movieDirector];
if ($movieActors) {
    $movieSchema['actor'] = array_map(static function ($actor) {
        return ['@type' => 'Person', 'name' => $actor];
    }, $movieActors);
}
if ($episodes) {
    $movieSchema['hasPart'] = array_map(static function ($episode) {
        return [
            '@type' => 'VideoObject',
            'name' => $episode['title'],
            'url' => $episode['absolute_url'],
        ];
    }, $episodes);
}
$movieJsonLd = json_encode(
    $movieSchema,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if (!is_string($movieJsonLd)) $movieJsonLd = '{}';

$primaryActionUrl = $episodes ? $episodes[0]['url'] : '#story';
$primaryActionText = $episodes ? '立即播放' : '查看详情';
$displayArea = $movieArea !== '' ? $movieArea : '暂无资料';
$displayClass = $movieClass !== '' ? $movieClass : '影视内容';
$displayYear = $movieYear !== '' ? $movieYear : '待公布';
$displayLanguage = $movieLanguage !== '' ? $movieLanguage : '中文';
$displayDirector = $movieDirector !== '' ? $movieDirector : '暂无资料';
$displayActors = $movieActorsText !== '' ? $movieActorsText : '暂无资料';
$displayStatus = $movieStatus !== '' ? $movieStatus : ($episodes ? '共 ' . count($episodes) . ' 集' : '详情已更新');
$displayQuality = $movieQuality !== '' ? $movieQuality : '影视详情';
?>
<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="description" content="<?= appx_escape($movieDescription) ?>">
  <meta name="robots" content="index,follow,max-snippet:-1,max-image-preview:large,max-video-preview:-1">
  <base href="<?= appx_escape($base_href) ?>">
  <link rel="canonical" href="<?= appx_escape($canonical) ?>">
  <title><?= appx_escape($movieTitle) ?></title>

  <meta property="og:type" content="videolist">
  <meta property="og:title" content="<?= appx_escape($movieTitle) ?>">
  <meta property="og:description" content="<?= appx_escape($movieDescription) ?>">
  <meta property="og:url" content="<?= appx_escape($canonical) ?>">
  <meta property="og:site_name" content="<?= appx_escape($site_name) ?>">
  <?php if ($moviePoster !== ''): ?><meta property="og:image" content="<?= appx_escape($moviePoster) ?>"><?php endif; ?>
  <?php if ($episodes): ?><meta property="og:video" content="<?= appx_escape($episodes[0]['absolute_url']) ?>"><?php endif; ?>
  <?php if ($movieArea !== ''): ?><meta property="og:video:area" content="<?= appx_escape($movieArea) ?>"><?php endif; ?>
  <?php if ($movieClass !== ''): ?><meta property="og:video:class" content="<?= appx_escape($movieClass) ?>"><?php endif; ?>
  <?php if ($movieYear !== ''): ?><meta property="og:video:release_date" content="<?= appx_escape($movieYear) ?>"><?php endif; ?>
  <?php if ($movieDirector !== ''): ?><meta property="og:video:director" content="<?= appx_escape($movieDirector) ?>"><?php endif; ?>
  <?php if ($movieActorsText !== ''): ?><meta property="og:video:actor" content="<?= appx_escape($movieActorsText) ?>"><?php endif; ?>
  <?php if ($movieLanguage !== ''): ?><meta property="og:video:language" content="<?= appx_escape($movieLanguage) ?>"><?php endif; ?>
  <?php if ($movieContentType !== ''): ?><meta property="og:video:content_type" content="<?= appx_escape($movieContentType) ?>"><?php endif; ?>
  <?php if ($episodes): ?>
  <meta property="og:video:update_new" content="<?= count($episodes) ?>">
  <meta property="og:video:update_total" content="<?= count($episodes) ?>">
  <?php endif; ?>
  <script type="application/ld+json"><?= $movieJsonLd ?></script>

  <style>
    :root{--bg:#0b0d12;--panel:#141820;--panel-2:#1b202a;--text:#f5f7fb;--muted:#9ba5b5;--line:rgba(255,255,255,.09);--red:#f04444;--red-dark:#cc3030;--gold:#f6c453;--shadow:0 24px 70px rgba(0,0,0,.34)}
    *{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:84px}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;-webkit-font-smoothing:antialiased}a{color:inherit;text-decoration:none}button{font:inherit}.shell{width:min(1180px,calc(100% - 40px));margin-inline:auto}.icon{width:1em;height:1em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
    .topbar{position:sticky;top:0;z-index:50;border-bottom:1px solid var(--line);background:rgba(11,13,18,.88);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}.topbar-inner{height:70px;display:flex;align-items:center;gap:40px}.brand{display:inline-flex;align-items:center;gap:11px;min-width:0;font-weight:800;letter-spacing:-.02em}.brand-mark{width:38px;height:38px;display:grid;place-items:center;border-radius:12px;background:linear-gradient(145deg,#ff5b55,#d72735);box-shadow:0 10px 25px rgba(240,68,68,.25)}.brand-mark .icon{font-size:21px;fill:#fff;stroke:none}.brand-name{max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nav{display:flex;align-items:center;gap:28px;color:#b2bac7;font-size:14px}.nav a:hover,.nav a:focus-visible{color:#fff}.search-pill{margin-left:auto;display:inline-flex;align-items:center;gap:8px;padding:9px 13px;border:1px solid var(--line);border-radius:999px;color:#a7b0bf;background:rgba(255,255,255,.035);font-size:13px}.search-pill .icon{font-size:16px}
    .page{padding:24px 0 70px}.breadcrumb{display:flex;align-items:center;gap:9px;min-width:0;margin-bottom:20px;color:#7f8999;font-size:13px}.breadcrumb a:hover{color:#fff}.breadcrumb span:last-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.breadcrumb .icon{font-size:14px}
    .movie-hero{position:relative;overflow:hidden;border:1px solid var(--line);border-radius:24px;background:radial-gradient(circle at 82% 18%,rgba(240,68,68,.18),transparent 34%),linear-gradient(135deg,#191d26,#101319 72%);box-shadow:var(--shadow)}.hero-grid{position:relative;z-index:1;display:grid;grid-template-columns:238px minmax(0,1fr);gap:38px;align-items:center;padding:38px}.poster{position:relative;overflow:hidden;aspect-ratio:2/3;border-radius:16px;background:linear-gradient(145deg,#2a303d,#151922);box-shadow:0 20px 44px rgba(0,0,0,.38)}.poster img{width:100%;height:100%;display:block;object-fit:cover}.poster-fallback{height:100%;display:grid;place-items:center;text-align:center;color:#fff;background:radial-gradient(circle at 30% 20%,rgba(255,255,255,.14),transparent 28%),linear-gradient(145deg,#ef4a50,#7c1727)}.poster-fallback .icon{display:block;margin:0 auto 14px;font-size:64px;fill:rgba(255,255,255,.92);stroke:none}.poster-fallback strong{display:block;padding:0 18px;font-size:18px;line-height:1.45}.quality{position:absolute;right:10px;top:10px;padding:5px 8px;border-radius:6px;background:rgba(0,0,0,.72);font-size:11px;font-weight:800}
    .hero-copy{min-width:0}.hero-tags{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}.hero-tags span{padding:6px 10px;border-radius:7px;background:rgba(255,255,255,.075);color:#d3d9e3;font-size:12px}.hero-tags .hot{background:rgba(240,68,68,.14);color:#ff7777}.hero-copy h1{margin:0;font-size:clamp(32px,4.5vw,52px);line-height:1.15;letter-spacing:-.04em;overflow-wrap:anywhere}.hero-desc{max-width:720px;margin:16px 0 22px;color:#aab3c2;font-size:15px;line-height:1.85;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px 28px;max-width:760px;margin:0 0 26px}.fact{display:grid;grid-template-columns:58px minmax(0,1fr);gap:8px;color:#dde2ea;font-size:14px;line-height:1.65}.fact dt{color:#7f8999}.fact dd{min-width:0;margin:0;overflow-wrap:anywhere}.hero-actions{display:flex;flex-wrap:wrap;gap:11px}.primary,.secondary{min-height:46px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 20px;border:1px solid transparent;border-radius:11px;font-weight:750;transition:transform .18s ease,background .18s ease,border-color .18s ease}.primary{background:var(--red);color:#fff;box-shadow:0 12px 28px rgba(240,68,68,.25)}.primary:hover{background:var(--red-dark);transform:translateY(-1px)}.secondary{border-color:var(--line);background:rgba(255,255,255,.055);color:#d9dfe8}.secondary:hover{border-color:rgba(255,255,255,.2);background:rgba(255,255,255,.085)}.primary .icon{fill:currentColor;stroke:none}
    .section{margin-top:22px;border:1px solid var(--line);border-radius:20px;background:var(--panel);box-shadow:0 14px 40px rgba(0,0,0,.14)}.section-inner{padding:28px}.section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin-bottom:20px}.section-head h2{margin:0;font-size:22px;letter-spacing:-.02em}.section-head p{margin:6px 0 0;color:var(--muted);font-size:13px}.section-kicker{display:block;margin-bottom:5px;color:#ff6565;font-size:11px;font-weight:850;letter-spacing:.12em}.update-chip{padding:7px 10px;border-radius:8px;background:rgba(255,255,255,.055);color:#98a3b3;font-size:12px}
    .episode-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:9px}.episode{min-height:42px;display:grid;place-items:center;padding:6px;border:1px solid var(--line);border-radius:9px;background:var(--panel-2);color:#cdd4df;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.episode:hover,.episode:focus-visible{border-color:rgba(240,68,68,.7);background:rgba(240,68,68,.11);color:#ff8585}.episode.active{border-color:var(--red);background:var(--red);color:#fff}
    .content-layout{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:22px;align-items:start;margin-top:22px}.content-layout .section{margin-top:0}.story{padding:30px}.story-lead{margin:0 0 22px;padding:18px 20px;border-left:3px solid var(--red);border-radius:0 10px 10px 0;background:rgba(240,68,68,.065);color:#c5ccd7;font-size:15px;line-height:1.8}.article-content{color:#b8c0cc;font-size:16px;line-height:1.95;overflow-wrap:anywhere}.article-content p{margin:0 0 1.2em}.article-content h2,.article-content h3,.article-content h4{margin:1.75em 0 .72em;color:#f4f6f9;line-height:1.4}.article-content img{display:block;max-width:100%;height:auto;margin:24px auto;border-radius:14px}.article-content a{color:#ff7777;text-decoration:underline;text-underline-offset:3px}.article-content ul,.article-content ol{padding-left:1.45em}.article-content blockquote{margin:1.5em 0;padding:14px 18px;border-left:3px solid #5f6979;background:#1a1f29;color:#c1c8d2}.article-content table{display:block;max-width:100%;overflow-x:auto;border-collapse:collapse}.article-content th,.article-content td{padding:10px 12px;border:1px solid var(--line)}
    .sidebar{position:sticky;top:92px;display:grid;gap:16px}.info-card,.recommend-card{padding:22px}.info-card h2,.recommend-card h2{margin:0 0 15px;font-size:17px}.info-list{margin:0}.info-list>div{display:grid;grid-template-columns:64px minmax(0,1fr);gap:9px;padding:11px 0;border-bottom:1px solid var(--line);font-size:13px;line-height:1.6}.info-list>div:last-child{border-bottom:0}.info-list dt{color:#7f8999}.info-list dd{margin:0;color:#d8dee7;overflow-wrap:anywhere}.related-list{display:grid;gap:10px}.related-item{display:grid;grid-template-columns:46px minmax(0,1fr);gap:11px;align-items:center;padding:9px;border:1px solid transparent;border-radius:11px;background:#191e27}.related-item:hover{border-color:var(--line);background:#1d232e}.related-thumb{width:46px;height:58px;display:grid;place-items:center;border-radius:7px;background:linear-gradient(145deg,#91303c,#33121c);color:#fff}.related-thumb .icon{font-size:21px;fill:currentColor;stroke:none}.related-copy{min-width:0}.related-copy strong{display:-webkit-box;overflow:hidden;color:#e5e9ef;font-size:13px;line-height:1.45;-webkit-line-clamp:2;-webkit-box-orient:vertical}.related-copy span{display:block;margin-top:5px;color:#7f8999;font-size:11px}
    .all-related{margin-top:22px}.related-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.related-tile{min-width:0;padding:17px;border:1px solid var(--line);border-radius:13px;background:var(--panel-2);transition:transform .18s ease,border-color .18s ease}.related-tile:hover{transform:translateY(-2px);border-color:rgba(240,68,68,.5)}.related-tile .tile-icon{width:38px;height:38px;display:grid;place-items:center;margin-bottom:14px;border-radius:10px;background:rgba(240,68,68,.12);color:#ff6b6b}.related-tile .icon{fill:currentColor;stroke:none}.related-tile h3{margin:0;color:#e7ebf1;font-size:14px;line-height:1.55;display:-webkit-box;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical}.related-tile p{margin:8px 0 0;color:#7f8999;font-size:11px}
    .footer{border-top:1px solid var(--line);background:#090b0f}.footer-inner{min-height:90px;display:flex;justify-content:space-between;align-items:center;gap:20px;color:#707989;font-size:12px}.footer nav{display:flex;gap:20px}.footer a:hover{color:#fff}.back-top{position:fixed;right:24px;bottom:24px;width:44px;height:44px;display:grid;place-items:center;border:1px solid var(--line);border-radius:12px;background:rgba(20,24,32,.92);color:#cbd2dc;box-shadow:0 12px 30px rgba(0,0,0,.24);cursor:pointer;opacity:0;visibility:hidden;transition:.2s}.back-top.show{opacity:1;visibility:visible}.back-top:hover{background:var(--red);color:#fff}
    a:focus-visible,button:focus-visible{outline:3px solid rgba(240,68,68,.32);outline-offset:3px}@media(max-width:1000px){.episode-grid{grid-template-columns:repeat(6,minmax(0,1fr))}.content-layout{grid-template-columns:1fr}.sidebar{position:static;grid-template-columns:1fr 1fr}}@media(max-width:760px){.shell{width:calc(100% - 24px)}.topbar-inner{height:60px}.nav,.search-pill{display:none}.brand-name{max-width:calc(100vw - 86px)}.page{padding-top:14px;padding-bottom:38px}.breadcrumb{margin-bottom:12px}.movie-hero{border-radius:18px}.hero-grid{grid-template-columns:118px minmax(0,1fr);gap:18px;align-items:start;padding:20px}.hero-copy h1{font-size:26px;line-height:1.25}.hero-desc{margin:11px 0 16px;font-size:13px;-webkit-line-clamp:3}.hero-tags{margin-bottom:10px}.facts{grid-template-columns:1fr;gap:7px;margin-bottom:18px}.fact{grid-template-columns:52px 1fr;font-size:12px}.hero-actions{grid-column:1/-1}.primary,.secondary{flex:1;min-height:43px;padding-inline:13px}.section{margin-top:14px;border-radius:16px}.section-inner,.story{padding:20px 17px}.section-head{align-items:flex-start;margin-bottom:16px}.section-head h2{font-size:19px}.update-chip{display:none}.episode-grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.content-layout{gap:14px;margin-top:14px}.story-lead{padding:15px}.article-content{font-size:15px;line-height:1.85}.sidebar{grid-template-columns:1fr;gap:14px}.related-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.footer-inner{min-height:76px;justify-content:center;text-align:center}.footer nav{display:none}.back-top{right:14px;bottom:14px}}@media(max-width:430px){.hero-grid{grid-template-columns:92px minmax(0,1fr);gap:14px;padding:16px}.poster{border-radius:11px}.poster-fallback .icon{font-size:36px}.poster-fallback strong{display:none}.hero-copy h1{font-size:21px}.hero-desc{font-size:12px;-webkit-line-clamp:2}.hero-tags span:nth-child(n+3){display:none}.facts .fact:nth-child(n+4){display:none}.hero-actions{gap:8px}.primary,.secondary{font-size:13px}.episode-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.related-grid{grid-template-columns:1fr}.section-head p{display:none}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}*,*::before,*::after{animation-duration:.01ms!important;transition-duration:.01ms!important}}
  </style>
</head>
<body>
  <svg width="0" height="0" aria-hidden="true" style="position:absolute;overflow:hidden">
    <symbol id="m-play" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></symbol>
    <symbol id="m-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></symbol>
    <symbol id="m-chevron" viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"/></symbol>
    <symbol id="m-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></symbol>
    <symbol id="m-film" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/></symbol>
    <symbol id="m-list" viewBox="0 0 24 24"><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="3" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="3" cy="18" r="1" fill="currentColor" stroke="none"/></symbol>
    <symbol id="m-up" viewBox="0 0 24 24"><path d="m6 15 6-6 6 6"/></symbol>
  </svg>

  <header class="topbar">
    <div class="shell topbar-inner">
      <a class="brand" href="./" aria-label="<?= appx_escape($site_name) ?>首页">
        <span class="brand-mark"><svg class="icon"><use href="#m-play"></use></svg></span>
        <span class="brand-name"><?= appx_escape($site_name) ?></span>
      </a>
      <nav class="nav" aria-label="主导航"><a href="./">首页</a><a href="#story">剧情介绍</a><a href="#episodes">播放列表</a><a href="#recommend">热门推荐</a></nav>
      <a class="search-pill" href="#recommend"><svg class="icon"><use href="#m-search"></use></svg>发现更多影视内容</a>
    </div>
  </header>

  <main class="shell page">
    <div class="breadcrumb"><a href="./">首页</a><svg class="icon"><use href="#m-chevron"></use></svg><span>影视</span><svg class="icon"><use href="#m-chevron"></use></svg><span><?= appx_escape($movieTitle) ?></span></div>

    <article class="movie-hero" aria-labelledby="movie-title">
      <div class="hero-grid">
        <div class="poster">
          <?php if ($moviePoster !== ''): ?>
          <img src="<?= appx_escape($moviePoster) ?>" alt="<?= appx_escape($movieTitle) ?>海报" width="480" height="720" loading="eager" fetchpriority="high">
          <?php else: ?>
          <div class="poster-fallback"><div><svg class="icon"><use href="#m-film"></use></svg><strong><?= appx_escape($movieTitle) ?></strong></div></div>
          <?php endif; ?>
          <span class="quality"><?= appx_escape($displayQuality) ?></span>
        </div>

        <div class="hero-copy">
          <div class="hero-tags"><span class="hot">热播推荐</span><span><?= appx_escape($displayClass) ?></span><span><?= appx_escape($displayStatus) ?></span></div>
          <h1 id="movie-title"><?= appx_escape($movieTitle) ?></h1>
          <p class="hero-desc"><?= appx_escape($movieDescription) ?></p>
          <dl class="facts">
            <div class="fact"><dt>导演</dt><dd><?= appx_escape($displayDirector) ?></dd></div>
            <div class="fact"><dt>主演</dt><dd><?= appx_escape($displayActors) ?></dd></div>
            <div class="fact"><dt>类型</dt><dd><?= appx_escape($displayClass) ?></dd></div>
            <div class="fact"><dt>地区</dt><dd><?= appx_escape($displayArea) ?></dd></div>
            <div class="fact"><dt>年份</dt><dd><?= appx_escape($displayYear) ?></dd></div>
            <div class="fact"><dt>语言</dt><dd><?= appx_escape($displayLanguage) ?></dd></div>
          </dl>
          <div class="hero-actions">
            <a class="primary" href="<?= appx_escape($primaryActionUrl) ?>"><svg class="icon"><use href="#m-play"></use></svg><?= appx_escape($primaryActionText) ?></a>
            <a class="secondary" href="#story"><svg class="icon"><use href="#m-info"></use></svg>剧情介绍</a>
          </div>
        </div>
      </div>
    </article>

    <?php if ($episodes): ?>
    <section id="episodes" class="section" aria-labelledby="episode-heading">
      <div class="section-inner">
        <div class="section-head"><div><span class="section-kicker">EPISODES</span><h2 id="episode-heading">播放列表</h2><p>选择剧集开始观看</p></div><span class="update-chip"><?= appx_escape($displayStatus) ?></span></div>
        <nav class="episode-list episode-grid" aria-label="剧集列表">
          <?php foreach ($episodes as $episodeIndex => $episode): ?>
          <a class="episode<?= $episodeIndex === 0 ? ' active' : '' ?>" href="<?= appx_escape($episode['url']) ?>"><?= appx_escape($episode['title']) ?></a>
          <?php endforeach; ?>
        </nav>
      </div>
    </section>
    <?php endif; ?>

    <div class="content-layout">
      <section id="story" class="section story" aria-labelledby="story-heading">
        <div class="section-head"><div><span class="section-kicker">STORY</span><h2 id="story-heading">剧情介绍</h2></div><span class="update-chip">更新于 __APPX_NOW__</span></div>
        <p class="story-lead"><?= appx_escape($movieDescription) ?></p>
        <div class="article-content"><?= $content ?></div>
      </section>

      <aside class="sidebar" aria-label="影视信息与推荐">
        <section class="section info-card">
          <h2>影视资料</h2>
          <dl class="info-list">
            <div><dt>片名</dt><dd><?= appx_escape($movieTitle) ?></dd></div>
            <div><dt>类型</dt><dd><?= appx_escape($displayClass) ?></dd></div>
            <div><dt>地区</dt><dd><?= appx_escape($displayArea) ?></dd></div>
            <div><dt>年份</dt><dd><?= appx_escape($displayYear) ?></dd></div>
            <div><dt>状态</dt><dd><?= appx_escape($displayStatus) ?></dd></div>
            <div><dt>更新</dt><dd>__APPX_DATE__</dd></div>
          </dl>
        </section>

        <?php if ($related): ?>
        <section class="section recommend-card">
          <h2>正在热播</h2>
          <div class="related-list">
            <?php foreach (array_slice($related, 0, 4) as $item): ?>
            <a class="related-item" href="<?= appx_escape((string) $item['url']) ?>"><span class="related-thumb"><svg class="icon"><use href="#m-play"></use></svg></span><span class="related-copy"><strong><?= appx_escape((string) $item['title']) ?></strong><span>影视详情 · 点击查看</span></span></a>
            <?php endforeach; ?>
          </div>
        </section>
        <?php endif; ?>
      </aside>
    </div>

    <?php if ($related): ?>
    <section id="recommend" class="section all-related" aria-labelledby="recommend-heading">
      <div class="section-inner">
        <div class="section-head"><div><span class="section-kicker">RECOMMENDED</span><h2 id="recommend-heading">猜你喜欢</h2><p>更多相关影视内容</p></div></div>
        <div class="related-grid">
          <?php foreach ($related as $item): ?>
          <a class="related-tile" href="<?= appx_escape((string) $item['url']) ?>"><span class="tile-icon"><svg class="icon"><use href="#m-play"></use></svg></span><h3><?= appx_escape((string) $item['title']) ?></h3><p>查看剧情与详细资料</p></a>
          <?php endforeach; ?>
        </div>
      </div>
    </section>
    <?php endif; ?>
  </main>

  <footer class="footer"><div class="shell footer-inner"><span>© <?= appx_escape((string) $year) ?> <?= appx_escape($site_name) ?> · 影视内容资料页</span><nav><a href="./">网站首页</a><a href="./sitemap.php">站点地图</a><a href="#story">剧情介绍</a><a href="#recommend">热门推荐</a></nav></div></footer>
  <button class="back-top" id="backTop" type="button" aria-label="回到顶部"><svg class="icon"><use href="#m-up"></use></svg></button>

  <script>
    (()=>{const button=document.getElementById('backTop');const update=()=>button.classList.toggle('show',window.scrollY>500);window.addEventListener('scroll',update,{passive:true});update();button.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));})();
  </script>
</body>
</html>
