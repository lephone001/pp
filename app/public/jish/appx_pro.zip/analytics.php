<?php
function appx_crawler_name($ua, $request = null)
{
    if (stripos($ua, 'Baiduspider') !== false) {
        return $request !== null && !empty($request['baidu_verified']) ? 'Baidu' : 'Unverified Baidu UA';
    }
    $map = ['Googlebot'=>'Google','bingbot'=>'Bing','Sogou'=>'Sogou','360Spider'=>'360','YisouSpider'=>'Yisou','Bytespider'=>'ByteDance','PetalBot'=>'Petal'];
    foreach ($map as $needle => $name) if (stripos($ua, $needle) !== false) return $name;
    return preg_match('/crawler|spider|bot\b/i', $ua) ? 'Other crawler' : '';
}

function appx_analytics_key($keyFile)
{
    $cacheKey = 'appx:analytics-key:' . hash('sha256', $keyFile);
    if (function_exists('apcu_fetch')) {
        $success = false;
        $cached = apcu_fetch($cacheKey, $success);
        if ($success && is_string($cached) && strlen($cached) >= 32) return $cached;
    }
    $key = @file_get_contents($keyFile);
    if (!is_string($key) || strlen($key) < 32) {
        $key = bin2hex(appx_random_bytes(32));
        if (!appx_atomic_write($keyFile, $key)) return null;
    }
    if (function_exists('apcu_store')) @apcu_store($cacheKey, $key, 86400);
    return $key;
}

function appx_record_visit($path, $config)
{
    if (empty($config['analytics_enabled'])) return;
    $dir = appx_data_dir() . DIRECTORY_SEPARATOR . '.analytics';
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) return;
    $keyFile = $dir . DIRECTORY_SEPARATOR . '.key';
    $key = appx_analytics_key($keyFile);
    if ($key === null) return;
    $request = appx_request_context($config);
    $record = [
        date('c'),
        substr(hash_hmac('sha256', (string) $request['ip'], $key), 0, 20),
        $request['mobile'] ? 'mobile' : 'desktop',
        appx_crawler_name((string) $request['user_agent'], $request),
        $path,
        substr((string) $request['referer'], 0, 500),
        substr((string) $request['user_agent'], 0, 500),
    ];
    $line = implode("\t", array_map(static function ($v) { return str_replace(["\r","\n","\t"], ' ', (string) $v); }, $record)) . "\n";
    /* One append file per PHP worker avoids every concurrent request waiting
       on the same daily LOCK_EX. A worker handles one request at a time. */
    $worker = function_exists('getmypid') ? max(0, (int) getmypid()) : 0;
    $logFile = $dir . DIRECTORY_SEPARATOR . date('Y-m-d') . '-p' . $worker . '.log';
    @file_put_contents($logFile, $line, FILE_APPEND);
}

function appx_analytics_summary($days = 7)
{
    $summary = ['total'=>0,'mobile'=>0,'desktop'=>0,'crawlers'=>[],'referrers'=>[]];
    $dir = appx_data_dir() . DIRECTORY_SEPARATOR . '.analytics';
    for ($i=0;$i<$days;$i++) {
        $date=date('Y-m-d',time()-86400*$i);
        $files=glob($dir.DIRECTORY_SEPARATOR.$date.'*.log')?:[];
        foreach($files as $file) foreach (@file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $parts=explode("\t",$line,7); if(count($parts)<7) continue; $summary['total']++;
            $device=$parts[2]; if(isset($summary[$device])) $summary[$device]++;
            if($parts[3]!=='') $summary['crawlers'][$parts[3]]=((isset($summary['crawlers'][$parts[3]]) ? $summary['crawlers'][$parts[3]] : 0))+1;
            $host=parse_url($parts[5],PHP_URL_HOST); if(is_string($host)&&$host!=='') $summary['referrers'][$host]=((isset($summary['referrers'][$host]) ? $summary['referrers'][$host] : 0))+1;
        }
    }
    arsort($summary['crawlers']); arsort($summary['referrers']); return $summary;
}
