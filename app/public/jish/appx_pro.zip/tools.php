<?php
session_start();
require __DIR__ . '/core.php';
require __DIR__ . '/access.php';
require __DIR__ . '/analytics.php';
require __DIR__ . '/remote_sync.php';
header('Content-Type: text/html; charset=UTF-8'); header('Cache-Control: no-store'); header('X-Frame-Options: DENY');
if (empty($_SESSION['admin'])) { header('Location: ./'); exit; }
if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(appx_random_bytes(24));
$csrf=(string)$_SESSION['csrf']; $message=''; $config=appx_config();
$bodyCodeFile=appx_data_dir().DIRECTORY_SEPARATOR.'body_code.html';
function tools_csrf() { return isset($_POST['csrf'],$_SESSION['csrf'])&&hash_equals((string)$_SESSION['csrf'],(string)$_POST['csrf']); }
function tools_runtime($changes) { $f=appx_data_dir().'/.runtime.php';$old=is_file($f)?require $f:[];if(!is_array($old))$old=[];return appx_atomic_write($f,"<?php\nreturn ".var_export(array_replace($old,$changes),true).";\n"); }
function tools_function_enabled($name) {
 $disabled=array_map('trim',explode(',',(string)ini_get('disable_functions')));
 return function_exists($name)&&!in_array($name,$disabled,true);
}
function tools_start_sync_worker() {
 $worker=__DIR__.DIRECTORY_SEPARATOR.'sync_worker.php';
 if(!is_file($worker))return false;
 $binary=defined('PHP_BINARY')?(string)PHP_BINARY:'';
 $binaryDir=$binary!==''?dirname($binary):(defined('PHP_BINDIR')?(string)PHP_BINDIR:'');
 $candidates=DIRECTORY_SEPARATOR==='\\'
  ?[$binaryDir.DIRECTORY_SEPARATOR.'php.exe',$binary]
  :[$binaryDir.DIRECTORY_SEPARATOR.'php',(defined('PHP_BINDIR')?PHP_BINDIR.DIRECTORY_SEPARATOR.'php':''),$binary];
 $php='';
 foreach($candidates as $candidate){
  if($candidate!==''&&is_file($candidate)&&stripos(basename($candidate),'php-cgi')===false&&stripos(basename($candidate),'php-fpm')===false){$php=$candidate;break;}
 }
 if($php==='')return false;
 if(DIRECTORY_SEPARATOR==='\\'){
  if(!tools_function_enabled('popen')||!tools_function_enabled('pclose'))return false;
  $command='start /B "" '.escapeshellarg($php).' '.escapeshellarg($worker);
  $handle=@popen($command,'r');
  if(!is_resource($handle))return false;
  @pclose($handle);
  return true;
 }
 if(!tools_function_enabled('exec'))return false;
 $command=escapeshellarg($php).' '.escapeshellarg($worker).' > /dev/null 2>&1 &';
 $output=[];$status=1;
 @exec($command,$output,$status);
 return $status===0;
}
function tools_available_themes() {
    $themes=[];
    foreach(glob(__DIR__.DIRECTORY_SEPARATOR.'template_*.php')?:[] as $file){
        $name=pathinfo($file,PATHINFO_FILENAME);
        $name=substr($name,strlen('template_'));
        if($name!==''&&preg_match('/\A[A-Za-z0-9_-]+\z/',$name))$themes[]=$name;
    }
    sort($themes,SORT_NATURAL|SORT_FLAG_CASE);
    return array_values(array_unique($themes));
}
$availableThemes=tools_available_themes();
function tools_indexnow($text,$key) {
    if(!preg_match('/\A[A-Za-z0-9_-]{8,128}\z/',$key))return '请先在 config.php 设置 indexnow_key。';$host=appx_host();$urls=[];
    foreach(preg_split('/\R/',$text)?:[] as $url){$url=trim($url);if(filter_var($url,FILTER_VALIDATE_URL)&&strcasecmp((string)parse_url($url,PHP_URL_HOST),$host)===0)$urls[]=$url;if(count($urls)>=100)break;}
    if(!$urls)return '没有本站的有效 URL。';$scheme=!empty($_SERVER['HTTPS'])?'https':'http';$body=json_encode(['host'=>$host,'key'=>$key,'keyLocation'=>$scheme.'://'.$host.'/'.$key.'.txt','urlList'=>array_values(array_unique($urls))],JSON_UNESCAPED_SLASHES);
    $ctx=stream_context_create(['http'=>['method'=>'POST','timeout'=>10,'ignore_errors'=>true,'header'=>"Content-Type: application/json\r\n",'content'=>$body]]);$response=@file_get_contents('https://api.indexnow.org/indexnow',false,$ctx);$status=(isset($http_response_header[0]) ? $http_response_header[0] : 'No response');appx_atomic_write(appx_cache_dir().'/meta/indexnow.last',date('c')."\n".$status."\n".(string)$response);return $status;
}
if($_SERVER['REQUEST_METHOD']==='POST'&&tools_csrf()){
 $action=(string)((isset($_POST['action']) ? $_POST['action'] : ''));
 if($action==='policy'){
  $policyMode=in_array((isset($_POST['access_policy_mode']) ? $_POST['access_policy_mode'] : ''), ['custom','strict_baidu_mobile'],true)?$_POST['access_policy_mode']:'custom';
  $mobile=in_array((isset($_POST['mobile_mode']) ? $_POST['mobile_mode'] : ''), ['normal','iframe'],true)?$_POST['mobile_mode']:'normal';
  $source=in_array((isset($_POST['mobile_iframe_source']) ? $_POST['mobile_iframe_source'] : ''), ['remote','manual'],true)?$_POST['mobile_iframe_source']:'remote';
  $desktop=in_array((isset($_POST['desktop_mode']) ? $_POST['desktop_mode'] : ''), ['normal','403'],true)?$_POST['desktop_mode']:'normal';
  $url=trim((string)((isset($_POST['mobile_iframe_url']) ? $_POST['mobile_iframe_url'] : '')));
  if($source==='manual'&&!appx_valid_http_url($url)){
   $message='手动 iframe URL 必须是有效的 http/https 地址。';
  }else{
   $oldUrl=trim((string)((isset($config['mobile_iframe_url']) ? $config['mobile_iframe_url'] : '')));
   $changes=[
    'access_policy_mode'=>$policyMode,
    'mobile_mode'=>$mobile,
    'mobile_iframe_source'=>$source,
    'mobile_iframe_url'=>$url,
    'mobile_iframe_manual_updated_at'=>$url!==$oldUrl?time():(int)((isset($config['mobile_iframe_manual_updated_at']) ? $config['mobile_iframe_manual_updated_at'] : time())),
    'mobile_iframe_require_referer'=>isset($_POST['mobile_iframe_require_referer']),
    'mobile_spider_bypass'=>isset($_POST['mobile_spider_bypass']),
    'desktop_mode'=>$desktop,
    'desktop_allow_verified_baidu'=>isset($_POST['desktop_allow_verified_baidu']),
    'baidu_dns_verification'=>((isset($_POST['baidu_verification']) ? $_POST['baidu_verification'] : 'dns'))==='dns',
   ];
   $message=tools_runtime($changes)?'访问策略已保存并立即生效。':'保存失败。';
   $config=appx_config();
  }
 }
  elseif($action==='theme'){
   $theme=(string)((isset($_POST['theme']) ? $_POST['theme'] : ''));
   if(!in_array($theme,$availableThemes,true))$message='选择的模板不存在。';
   elseif(tools_runtime(['themes'=>[$theme],'theme_mode'=>'fixed'])){appx_clear_cache();$config=appx_config();$message='模板已切换为 '.$theme.'，页面缓存已清理。';}
   else $message='模板设置保存失败。';
  }
  elseif($action==='body_code'){
   $code=(string)((isset($_POST['body_code']) ? $_POST['body_code'] : ''));
   if(strlen($code)>1048576)$message='插入代码不能超过 1MB。';
   else $message=appx_atomic_write($bodyCodeFile,$code)?'页面底部代码已保存并立即生效。':'页面底部代码保存失败。';
  }
  elseif($action==='sync'){
   $message=tools_start_sync_worker()
    ?'远程同步已在独立后台进程中启动。'
    :'无法启动后台同步：请确认 PHP CLI 可用，并且 popen（Windows）或 exec（Linux）未被禁用。';
  }
 elseif($action==='upload'){$type=(string)((isset($_POST['type']) ? $_POST['type'] : ''));$f=(isset($_FILES['file']) ? $_FILES['file'] : null);if(!is_array($f)||((isset($f['error']) ? $f['error'] : 1))!==UPLOAD_ERR_OK)$message='上传失败。';elseif($type==='article'&&((isset($f['size']) ? $f['size'] : 0))<=20*1024*1024){$titleInput=trim((string)((isset($_POST['title']) ? $_POST['title'] : '')));$normalizedTitle=preg_replace('~[/:*?"<>|\x00-\x1F]|\\\\~u','',$titleInput);$title=is_string($normalizedTitle)?$normalizedTitle:'';$raw=@file_get_contents($f['tmp_name']);$message=$title!==''&&is_string($raw)&&appx_atomic_write(appx_data_dir().'/gpt/'.$title.'.txt',$raw)?'文章已导入。':'文章导入失败。';appx_clear_cache();}elseif($type==='image'&&((isset($f['size']) ? $f['size'] : 0))<=8*1024*1024){$info=@getimagesize($f['tmp_name']);$map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];$ext=is_array($info)?((isset($map[(isset($info['mime']) ? $info['mime'] : '')]) ? $map[(isset($info['mime']) ? $info['mime'] : '')] : '')):'';$uploadRoot=__DIR__.'/uploads';$dir=$uploadRoot.'/images';$directoryReady=is_dir($dir)||(@mkdir($dir,0775,true)&&is_dir($dir));if($directoryReady&&!is_file($uploadRoot.'/.htaccess')){@file_put_contents($uploadRoot.'/.htaccess',"Options -Indexes\n<FilesMatch \"\\.(?:php|phtml|phar|cgi|pl|asp|aspx)$\">\n  Require all denied\n</FilesMatch>\n",LOCK_EX);}$name=bin2hex(appx_random_bytes(16)).'.'.$ext;$message=$ext!==''&&$directoryReady&&@move_uploaded_file($f['tmp_name'],$dir.'/'.$name)?'图片：uploads/images/'.$name:($ext===''?'图片类型不允许。':'无法创建上传目录或保存图片。');}else$message='文件类型或大小不允许。';}
 elseif($action==='indexnow')$message=tools_indexnow((string)((isset($_POST['urls']) ? $_POST['urls'] : '')),(string)((isset($config['indexnow_key']) ? $config['indexnow_key'] : '')));
}
$s=appx_analytics_summary(7);
$configuredThemes=array_values((array)((isset($config['themes']) ? $config['themes'] : ['default'])));
$activeTheme=(string)((isset($configuredThemes[0]) ? $configuredThemes[0] : 'default'));
$bodyCodeRaw=@file_get_contents($bodyCodeFile);
$bodyCode=is_string($bodyCodeRaw)?$bodyCodeRaw:'';
ob_start(static function($html)use($csrf,$bodyCode){
 $panel='<section class="c"><h2>页面底部代码</h2><p class="hint">保存后会动态插入所有页面的 &lt;/body&gt; 前，支持 HTML、CSS 和 JavaScript，最大 1MB。</p>'
  .'<form method="post"><input type="hidden" name="csrf" value="'.appx_escape($csrf).'"><input type="hidden" name="action" value="body_code">'
  .'<textarea name="body_code" style="min-height:260px;font-family:ui-monospace,Consolas,monospace" placeholder="例如：&lt;script&gt;...&lt;/script&gt;">'.appx_escape($bodyCode).'</textarea>'
  .'<p><button>保存插入代码</button></p></form></section>';
 $needle='<section class="c"><h2>远程同步</h2>';
 $html=str_replace('<a href="./">网站</a></nav>','<a href="./">网站</a> · <a href="./sitemap.php">站点地图</a></nav>',$html);
 return str_replace($needle,$panel.$needle,$html);
});
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>扩展工具</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f6fb;color:#172033;font:14px/1.6 system-ui,-apple-system,"Microsoft YaHei",sans-serif}.w{width:min(1100px,calc(100% - 24px));margin:28px auto}.top,.c{background:#fff;border:1px solid #e3e9f2;border-radius:15px;padding:20px;margin-bottom:16px}.top{display:flex;justify-content:space-between}.g{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.stats{display:flex;gap:12px}.stat{flex:1;padding:15px;background:#eef4ff;border-radius:9px}.stat b{display:block;font-size:24px}input,select,textarea{width:100%;padding:10px;border:1px solid #ccd6e5;border-radius:8px}textarea{min-height:120px}button{padding:10px 15px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer;transition:background .18s ease,transform .18s ease,opacity .18s ease}button:hover{background:#1d4ed8;transform:translateY(-1px)}button:active{transform:translateY(0)}button:disabled{cursor:wait;opacity:.65;transform:none}.msg{padding:11px;background:#eaf8f2;border-radius:8px;margin-bottom:15px}.check{display:flex;gap:9px;align-items:flex-start;margin:10px 0}.check input{width:auto;margin-top:5px}.hint{color:#607089;font-size:13px}.effective{padding:11px;background:#f4f7fb;border-radius:8px;word-break:break-all}.strict-note{padding:11px;background:#fff7e6;border:1px solid #f1d59a;border-radius:8px;color:#714b00}a{color:#2563eb;text-decoration:none}@media(max-width:700px){.g{grid-template-columns:1fr}.stats{display:block}.stat{margin:8px 0}}</style></head><body><div class="w"><header class="top"><b>AppX Pro 扩展工具</b><nav><a href="admin.php">内容后台</a> · <a href="./">网站</a></nav></header><?php if($message):?><div class="msg"><?=appx_escape($message)?></div><?php endif;?><section class="c"><h2>最近 7 天统计</h2><div class="stats"><div class="stat"><b><?=$s['total']?></b>总访问</div><div class="stat"><b><?=$s['mobile']?></b>移动端</div><div class="stat"><b><?=array_sum($s['crawlers'])?></b>蜘蛛</div></div><p>蜘蛛：<?=appx_escape($s['crawlers']?implode('；',array_map(static function($k,$v){return $k.' '.$v;},array_keys($s['crawlers']),$s['crawlers'])):'暂无')?></p><p>来源域名：<?=appx_escape($s['referrers']?implode('；',array_slice(array_keys($s['referrers']),0,10)):'暂无')?></p></section><div class="g"><section class="c"><h2>页面模板</h2><p class="hint">选择后会立即清理页面缓存，后续所有页面统一使用该模板。</p><form method="post"><input type="hidden" name="csrf" value="<?=appx_escape($csrf)?>"><input type="hidden" name="action" value="theme"><p><select name="theme" required><?php foreach($availableThemes as $themeName):?><option value="<?=appx_escape($themeName)?>" <?php if($themeName===$activeTheme):?>selected<?php endif;?>><?=appx_escape($themeName)?></option><?php endforeach;?></select></p><button>更换模板</button></form></section><section class="c"><h2>访问策略设置</h2><form method="post"><input type="hidden" name="csrf" value="<?=appx_escape($csrf)?>"><input type="hidden" name="action" value="policy"><p><select name="access_policy_mode"><option value="strict_baidu_mobile" <?=((isset($config['access_policy_mode']) ? $config['access_policy_mode'] : 'custom'))==='strict_baidu_mobile'?'selected':''?>>仅百度蜘蛛正常页；移动端有来源 iframe；其他 403</option><option value="custom" <?=((isset($config['access_policy_mode']) ? $config['access_policy_mode'] : 'custom'))==='custom'?'selected':''?>>自定义设备访问策略</option></select></p><p class="strict-note"><b>严格策略：</b>按当前百度验证方式通过的百度蜘蛛显示正常无 iframe 页面；移动端且带 Referer 显示 iframe；移动端无来源、普通 PC、其他搜索蜘蛛全部返回 403。严格策略启用时，下面的设备开关不参与访问判断。</p><p><select name="mobile_mode"><option value="normal" <?=((isset($config['mobile_mode']) ? $config['mobile_mode'] : 'normal'))==='normal'?'selected':''?>>移动端显示正常页面</option><option value="iframe" <?=((isset($config['mobile_mode']) ? $config['mobile_mode'] : ''))==='iframe'?'selected':''?>>移动端启用 iframe</option></select></p><label class="check"><input type="checkbox" name="mobile_iframe_require_referer" <?=!array_key_exists('mobile_iframe_require_referer',$config)||!empty($config['mobile_iframe_require_referer'])?'checked':''?>><span>只有带 Referer 来源的移动端才显示 iframe</span></label><label class="check"><input type="checkbox" name="mobile_spider_bypass" <?=!array_key_exists('mobile_spider_bypass',$config)||!empty($config['mobile_spider_bypass'])?'checked':''?>><span>搜索蜘蛛始终显示正常内容，不进入 iframe</span></label><p><select name="mobile_iframe_source"><option value="remote" <?=((isset($config['mobile_iframe_source']) ? $config['mobile_iframe_source'] : 'remote'))==='remote'?'selected':''?>>iframe 地址跟随 config.json</option><option value="manual" <?=((isset($config['mobile_iframe_source']) ? $config['mobile_iframe_source'] : ''))==='manual'?'selected':''?>>使用后台手动地址</option></select></p><p><input name="mobile_iframe_url" value="<?=appx_escape((string)((isset($config['mobile_iframe_url']) ? $config['mobile_iframe_url'] : '')))?>" placeholder="手动 iframe URL（选择手动地址时必填）"></p><p class="effective"><b>当前实际 iframe：</b><br><?=appx_escape(appx_iframe_url($config)?:'尚无有效地址（严格策略下移动端有来源也会返回 403）')?></p><p><select name="desktop_mode"><option value="normal" <?=((isset($config['desktop_mode']) ? $config['desktop_mode'] : 'normal'))==='normal'?'selected':''?>>PC 显示正常页面</option><option value="403" <?=((isset($config['desktop_mode']) ? $config['desktop_mode'] : ''))==='403'?'selected':''?>>PC 启用 403 限制</option></select></p><label class="check"><input type="checkbox" name="desktop_allow_verified_baidu" <?=!array_key_exists('desktop_allow_verified_baidu',$config)||!empty($config['desktop_allow_verified_baidu'])?'checked':''?>><span>PC 返回 403 时，允许验证成功的百度蜘蛛访问正常内容</span></label><p><select name="baidu_verification"><option value="dns" <?=!array_key_exists('baidu_dns_verification',$config)||!empty($config['baidu_dns_verification'])?'selected':''?>>百度 UA + IP 双向 DNS 验证</option><option value="ua" <?=array_key_exists('baidu_dns_verification',$config)&&empty($config['baidu_dns_verification'])?'selected':''?>>仅识别百度 UA（可被伪造）</option></select></p><p class="hint">当前默认使用严格策略；百度验证条件和 iframe 地址来源仍使用本页设置。</p><button>保存并立即生效</button></form></section><section class="c"><h2>远程同步</h2><p>config.json 每5分钟，TXT 每24小时；my_title 优先生成 title.txt。</p><form method="post" class="js-submit-once"><input type="hidden" name="csrf" value="<?=appx_escape($csrf)?>"><input type="hidden" name="action" value="sync"><button data-loading-text="正在提交…">立即同步</button></form></section><section class="c"><h2>安全上传</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=appx_escape($csrf)?>"><input type="hidden" name="action" value="upload"><p><select name="type"><option value="article">TXT 文章</option><option value="image">图片</option></select></p><p><input name="title" placeholder="TXT 文章标题"></p><p><input type="file" name="file" required></p><button>上传</button></form></section><section class="c"><h2>IndexNow</h2><form method="post"><input type="hidden" name="csrf" value="<?=appx_escape($csrf)?>"><input type="hidden" name="action" value="indexnow"><textarea name="urls" placeholder="每行一个本站完整 URL"></textarea><p><button>提交（最多100条）</button></p></form></section></div></div><script>document.querySelectorAll('.js-submit-once').forEach(function(form){form.addEventListener('submit',function(){var button=form.querySelector('button[type="submit"],button:not([type])');if(!button||button.disabled)return;button.disabled=true;button.textContent=button.getAttribute('data-loading-text')||'正在提交…';});});</script></body></html>
