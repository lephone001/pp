<?php
session_start();
require __DIR__ . '/core.php';

header('Content-Type: text/html; charset=UTF-8');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

const ADMIN_FIXED_PASSWORD = '123123';
$message = '';

function admin_csrf()
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(appx_random_bytes(24));
    return (string) $_SESSION['csrf'];
}
function admin_valid_csrf()
{
    return isset($_POST['csrf']) && hash_equals(admin_csrf(), (string) $_POST['csrf']);
}
function admin_article_name($title)
{
    $normalizedTitle = preg_replace('/\s+/u', ' ', $title);
    $title = trim(is_string($normalizedTitle) ? $normalizedTitle : $title);
    $length = function_exists('mb_strlen') ? mb_strlen($title, 'UTF-8') : strlen($title);
    if ($title === '' || $length > 160 || preg_match('~[/:*?"<>|\x00-\x1F]|\\\\~u', $title)) return null;
    return $title . '.txt';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ((isset($_POST['action']) ? $_POST['action'] : '')) === 'login' && admin_valid_csrf()) {
    if (hash_equals(ADMIN_FIXED_PASSWORD, (string) ((isset($_POST['password']) ? $_POST['password'] : '')))) {
        session_regenerate_id(true); $_SESSION['admin'] = true;
    } else $message = '密码错误。';
}
if (isset($_GET['logout'])) { $_SESSION = []; session_destroy(); header('Location: ./'); exit; }

$loggedIn = !empty($_SESSION['admin']);
if ($loggedIn && $_SERVER['REQUEST_METHOD'] === 'POST' && admin_valid_csrf()) {
    $action = (string) ((isset($_POST['action']) ? $_POST['action'] : ''));
    if ($action === 'save_data') {
        $allowed = ['title.txt','description.txt','content.txt','image.txt','config.txt','content_0.txt','content_1.txt','content_2.txt','content_3.txt','content_4.txt','content_5.txt','content_6.txt'];
        $name = (string) ((isset($_POST['name']) ? $_POST['name'] : ''));
        $content = (string) ((isset($_POST['content']) ? $_POST['content'] : ''));
        if (in_array($name, $allowed, true) && strlen($content) <= 10 * 1024 * 1024 && appx_atomic_write(appx_data_dir() . '/' . $name, $content)) {
            appx_clear_cache(); $message = '数据文件已保存，页面缓存已清理。';
        } else $message = '文件名或内容不符合要求。';
    } elseif ($action === 'save_article') {
        $old = basename((string) ((isset($_POST['old_name']) ? $_POST['old_name'] : '')));
        $name = admin_article_name((string) ((isset($_POST['title']) ? $_POST['title'] : '')));
        $content = (string) ((isset($_POST['content']) ? $_POST['content'] : ''));
        $dir = appx_data_dir() . '/gpt'; if (!is_dir($dir)) @mkdir($dir, 0775, true);
        if ($name && strlen($content) <= 20 * 1024 * 1024 && appx_atomic_write($dir . '/' . $name, $content)) {
            if ($old !== '' && $old !== $name && preg_match('/\.txt\z/i', $old)) @unlink($dir . '/' . $old);
            appx_clear_cache(); $message = '文章已保存，文章索引和页面缓存已更新。';
        } else $message = '标题含非法字符或正文过大。';
    } elseif ($action === 'delete_article') {
        $name = basename((string) ((isset($_POST['name']) ? $_POST['name'] : '')));
        if (preg_match('/\.txt\z/i', $name) && is_file(appx_data_dir() . '/gpt/' . $name) && @unlink(appx_data_dir() . '/gpt/' . $name)) {
            appx_clear_cache(); $message = '文章已删除。';
        } else $message = '文章不存在或无法删除。';
    } elseif ($action === 'clear_cache') {
        $message = '已清理 ' . appx_clear_cache() . ' 个页面缓存。';
    }
}

$dataFiles = ['title.txt','description.txt','content.txt','image.txt','config.txt','content_0.txt','content_1.txt','content_2.txt','content_3.txt','content_4.txt','content_5.txt','content_6.txt'];
$selectedData = in_array((string) ((isset($_GET['data']) ? $_GET['data'] : '')), $dataFiles, true) ? (string) $_GET['data'] : 'title.txt';
$dataContent = $loggedIn ? (string) @file_get_contents(appx_data_dir() . '/' . $selectedData) : '';
$manifest = $loggedIn ? appx_gpt_manifest() : [];
$page = max(1, (int) ((isset($_GET['page']) ? $_GET['page'] : 1))); $perPage = 40; $pages = max(1, (int) ceil(count($manifest) / $perPage)); $page = min($page, $pages);
$visible = array_slice($manifest, ($page - 1) * $perPage, $perPage);
$editName = $loggedIn ? basename((string) ((isset($_GET['article']) ? $_GET['article'] : ''))) : '';
$editContent = $editName !== '' && preg_match('/\.txt\z/i', $editName) ? (string) @file_get_contents(appx_data_dir() . '/gpt/' . $editName) : '';
$editTitle = $editName !== '' ? pathinfo($editName, PATHINFO_FILENAME) : '';
ob_start(static function ($html) {
    return str_replace(
        '<a href="?logout=1">',
        '<a href="./sitemap.php">站点地图</a> · <a href="?logout=1">',
        $html
    );
});
?>
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AppX Pro 管理后台</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f6fb;color:#172033;font:14px/1.6 system-ui,-apple-system,"Microsoft YaHei",sans-serif}.wrap{width:min(1180px,calc(100% - 24px));margin:30px auto}.top,.card{background:#fff;border:1px solid #e3e9f2;border-radius:16px;box-shadow:0 10px 28px rgba(25,42,75,.06)}.top{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;margin-bottom:18px}.grid{display:grid;grid-template-columns:250px 1fr;gap:18px}.card{padding:22px}h1,h2{margin:0 0 16px}a{color:#2563eb;text-decoration:none}.nav a{display:block;padding:8px 10px;border-radius:8px}.nav a:hover{background:#eef4ff}textarea,input{width:100%;padding:11px;border:1px solid #ccd6e5;border-radius:9px;font:inherit}textarea{min-height:360px;font-family:ui-monospace,Consolas,monospace}button{padding:10px 16px;border:0;border-radius:9px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer}.danger{background:#c93636}.msg{padding:11px 14px;margin-bottom:16px;border-radius:9px;background:#eaf8f2;color:#12664c}.articles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.article-item{display:flex;gap:8px;align-items:center;padding:9px;border:1px solid #e7ebf2;border-radius:9px}.article-item a{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.article-item form{margin:0}.pager{margin-top:15px}.pager a{margin-right:10px}@media(max-width:760px){.grid{grid-template-columns:1fr}.articles{grid-template-columns:1fr}}</style></head><body><div class="wrap">
<?php if (!$loggedIn): ?><section class="card" style="max-width:520px;margin:auto"><h1>管理后台登录</h1><?php if ($message): ?><div class="msg"><?= appx_escape($message) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= appx_escape(admin_csrf()) ?>"><input type="hidden" name="action" value="login"><p><input type="password" name="password" required placeholder="管理员密码"></p><button>登录</button></form></section>
<?php else: ?><header class="top"><strong>AppX Pro 管理后台</strong><nav><a href="tools.php">扩展工具</a> · <a href="./">查看网站</a> · <a href="?logout=1">退出</a></nav></header><?php if ($message): ?><div class="msg"><?= appx_escape($message) ?></div><?php endif; ?><div class="grid"><aside class="card nav"><h2>数据文件</h2><?php foreach ($dataFiles as $name): ?><a href="?data=<?= urlencode($name) ?>"><?= appx_escape($name) ?></a><?php endforeach; ?><hr><a href="?article=">新建 GPT 文章</a><form method="post" style="margin-top:15px"><input type="hidden" name="csrf" value="<?= appx_escape(admin_csrf()) ?>"><input type="hidden" name="action" value="clear_cache"><button>清理页面缓存</button></form></aside><main>
<section class="card"><h2>编辑 <?= appx_escape($selectedData) ?></h2><form method="post"><input type="hidden" name="csrf" value="<?= appx_escape(admin_csrf()) ?>"><input type="hidden" name="action" value="save_data"><input type="hidden" name="name" value="<?= appx_escape($selectedData) ?>"><textarea name="content"><?= appx_escape($dataContent) ?></textarea><p><button>保存数据文件</button></p></form></section>
<section class="card" style="margin-top:18px"><h2><?= $editName ? '编辑文章' : '新建 GPT 文章' ?></h2><form method="post"><input type="hidden" name="csrf" value="<?= appx_escape(admin_csrf()) ?>"><input type="hidden" name="action" value="save_article"><input type="hidden" name="old_name" value="<?= appx_escape($editName) ?>"><p><input name="title" value="<?= appx_escape($editTitle) ?>" required maxlength="160" placeholder="文章标题（将作为文件名）"></p><textarea name="content" placeholder="正文允许预先准备好的 HTML"><?= appx_escape($editContent) ?></textarea><p><button>保存文章</button></p></form></section>
<section class="card" style="margin-top:18px"><h2>GPT 文章（<?= count($manifest) ?>）</h2><div class="articles"><?php foreach ($visible as $name): ?><div class="article-item"><a href="?article=<?= urlencode($name) ?>"><?= appx_escape(pathinfo($name, PATHINFO_FILENAME)) ?></a><form method="post" onsubmit="return confirm('确定删除？')"><input type="hidden" name="csrf" value="<?= appx_escape(admin_csrf()) ?>"><input type="hidden" name="action" value="delete_article"><input type="hidden" name="name" value="<?= appx_escape($name) ?>"><button class="danger">删除</button></form></div><?php endforeach; ?></div><div class="pager"><?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>">上一页</a><?php endif; ?>第 <?= $page ?>/<?= $pages ?> 页<?php if ($page < $pages): ?> <a href="?page=<?= $page+1 ?>">下一页</a><?php endif; ?></div></section></main></div><?php endif; ?></div></body></html>
